package Presentation.Controllers;

import Exceptions.BusinessException;
import Business.Managers.UserManager;
import Exceptions.SignUpException;
import Presentation.Views.JFrames.ChangeViewer;
import Presentation.Views.JFrames.PrincipalViewer;
import Presentation.Views.SignUpView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Presentation.Views.Tools.Constants;


/**
 * Controller of the SignUpView.
 */
public class SignUpController implements ActionListener {
    private final ChangeViewer changeViewer;
    private final PrincipalViewer principalViewer;
    private final UserManager userManager;
    private final SignUpView signUpView;
    private final IntermediatePanelController intermediatePanelController;

    /**
     * Constructor of the view SignUpView.
     * @param changeViewer JFrame that has the SignView.
     * @param principalViewer JFrame that has some of the views where you will go from the SignView.
     * @param signUpView View that is managed in this controller.
     * @param userManager Manager that gets works with the information of the users.
     * @param intermediatePanelController controller of the intermediatePanel view
     */
    public SignUpController(ChangeViewer changeViewer, PrincipalViewer principalViewer, SignUpView signUpView, UserManager userManager, IntermediatePanelController intermediatePanelController){
        this.signUpView = signUpView;
        this.userManager = userManager;
        this.principalViewer = principalViewer;
        this.changeViewer = changeViewer;
        this.intermediatePanelController = intermediatePanelController;
        signUpView.actionPerform(this);
    }

    /**
     * Method used to perform all the actions  related with the sign-up view
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case Constants.BEGIN_ACTION:
                changeViewer.changeView(Constants.BEGIN_ACTION);
                signUpView.clearFields();
                break;
            case Constants.INTERMEDIATE_ACTION:
                String username = signUpView.getUser();
                String email = signUpView.getMail();
                String password = signUpView.getPassword();
                String confirmPassword = signUpView.getConfirmPassword();
                try {
                    boolean isRegisterSuccess = userManager.signUp(username, password,confirmPassword, email);
                    if(isRegisterSuccess){
                        userManager.startNewUser();
                        changeViewer.dispose();
                        principalViewer.startView();
                        principalViewer.changeView(Constants.INTERMEDIATE_ACTION);
                        intermediatePanelController.configurationOfTheTable();
                        signUpView.clearFields();
                    } else{
                        signUpView.showPopUp("Algunos campos obligatorios estan vacíos. Por favor, inténtelo de nuevo.");
                        signUpView.clearFields();
                    }
                } catch (BusinessException | SignUpException ex) {
                    signUpView.showPopUp(ex.getMessage());
                    signUpView.clearFields();
                }
                break;
            default:
                break;
        }
    }
}