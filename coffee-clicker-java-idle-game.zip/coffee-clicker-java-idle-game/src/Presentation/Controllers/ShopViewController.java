package Presentation.Controllers;

import Business.Entities.Game;
import Exceptions.BusinessException;
import Exceptions.NoMoreMacacosException;
import Business.Managers.GameManager;
import Presentation.Views.ShopView;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
/**
 * Controller for handling interactions with the ShopView.
 */
public class ShopViewController implements MouseListener {
    private final ShopView shopView;
    private final GameManager gameManager;
    private final LeftContainerController leftContainerController;

    /**
     * Constructs a ShopViewController with the specified dependencies.
     *
     * @param shopView              The ShopView instance associated with this controller.
     * @param gameManager           The GameManager instance for game-related operations.
     * @param leftContainerController The LeftContainerController instance for left container operations.
     */
    public ShopViewController(ShopView shopView, GameManager gameManager, LeftContainerController leftContainerController) {
        this.shopView = shopView;
        this.gameManager = gameManager;
        this.leftContainerController = leftContainerController;

        shopView.getTable().addMouseListener(this);
    }

    /**
     * Handles mouse click events on the shop view table.
     *
     * @param e The MouseEvent triggering the action.
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        int row = shopView.getTable().rowAtPoint(e.getPoint());
        if (row >= 0) {
            int selectedRow = shopView.getSelectedRowIndex();
            int columnCount = shopView.getTable().getColumnCount();
            Object[] rowData = new Object[columnCount];
            for (int col = 0; col < columnCount; col++) {
                rowData[col] = shopView.getTable().getValueAt(row, col);
            }

            try{
                ArrayList<Integer> costsBases = gameManager.getInfoCostBase();
                shopView.setCostBaseA(costsBases.get(0));
                shopView.setCostBaseB(costsBases.get(1));
                shopView.setCostBaseC(costsBases.get(2));

                Game updatedGame = gameManager.decreaseMacacos(selectedRow);
                if(updatedGame != null) {
                    leftContainerController.setMacacoNumber(gameManager.getInitialMacacoNumber(gameManager.getCurrentGameId()));
                    gameManager.addGeneratorToGame(rowData);
                    leftContainerController.updateMacacoView();
                }
            } catch(NoMoreMacacosException | BusinessException k){
                shopView.showPopUp(k.getMessage());
            }
        }
    }

    /**
     * Handles mouse press events on the shop view.
     *
     * @param e The MouseEvent triggering the action.
     */
    @Override
    public void mousePressed(MouseEvent e) {
        ArrayList<Integer> costsBases = gameManager.getInfoCostBase();
        shopView.setCostBaseA(costsBases.get(0));
        shopView.setCostBaseB(costsBases.get(1));
        shopView.setCostBaseC(costsBases.get(2));
    }

    /**
     * Handles mouse release events on the shop view.
     *
     * @param e The MouseEvent triggering the action.
     */
    @Override
    public void mouseReleased(MouseEvent e) {
        ArrayList<Integer> costsBases = gameManager.getInfoCostBase();
        shopView.setCostBaseA(costsBases.get(0));
        shopView.setCostBaseB(costsBases.get(1));
        shopView.setCostBaseC(costsBases.get(2));
    }

    /**
     * Handles mouse enter events on the shop view.
     *
     * @param e The MouseEvent triggering the action.
     */
    @Override
    public void mouseEntered(MouseEvent e) {
        ArrayList<Integer> costsBases = gameManager.getInfoCostBase();
        shopView.setCostBaseA(costsBases.get(0));
        shopView.setCostBaseB(costsBases.get(1));
        shopView.setCostBaseC(costsBases.get(2));
    }

    /**
     * Handles mouse exit events on the shop view.
     *
     * @param e The MouseEvent triggering the action.
     */
    @Override
    public void mouseExited(MouseEvent e) {
        ArrayList<Integer> costsBases = gameManager.getInfoCostBase();
        shopView.setCostBaseA(costsBases.get(0));
        shopView.setCostBaseB(costsBases.get(1));
        shopView.setCostBaseC(costsBases.get(2));
    }
}