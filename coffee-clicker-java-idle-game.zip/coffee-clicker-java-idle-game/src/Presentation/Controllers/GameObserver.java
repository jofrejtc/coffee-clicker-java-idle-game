package Presentation.Controllers;

/**
 * Interface for observing changes in the game state, particularly updates to the Macaco number.
 * Implementing classes should define the behavior for updating the Macaco number.
 */
public interface GameObserver {
    /**
     * Updates the Macaco number based on the latest game state.
     *
     * @param macacoNumber the new Macaco number to be updated.
     */
    void updateMacacoNumber(float macacoNumber);
}
