package Presentation.Controllers;

import Exceptions.BusinessException;
import Business.Managers.GameManager;
import Business.Managers.UserManager;
import Presentation.Views.IntermediatePanel;
import Presentation.Views.JFrames.ChangeViewer;
import Presentation.Views.JFrames.PrincipalViewer;
import Presentation.Views.Tools.Constants;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
/**
 * Controller class for managing interactions between the IntermediatePanel and other components.
 * Handles user actions and updates the IntermediatePanel accordingly.
 */
public class IntermediatePanelController implements ActionListener, MouseListener {
    private final PrincipalViewer principalViewer;
    private final IntermediatePanel intermediatePanel;
    private final LeftContainerController leftContainerController;
    private final ChangeViewer changeViewer;
    private final GameManager gameManager;
    private final UserManager userManager;
    /**
     * Constructs an IntermediatePanelController with the specified dependencies.
     * Initializes necessary components and sets up event listeners.
     *
     * @param changeViewer          The ChangeViewer instance for changing views.
     * @param principalViewer       The PrincipalViewer instance for main view operations.
     * @param leftContainerController The LeftContainerController instance for left container operations.
     * @param intermediatePanel     The IntermediatePanel instance associated with this controller.
     * @param gameManager           The GameManager instance for game-related operations.
     * @param userManager           The UserManager instance for user-related operations.
     */
    public IntermediatePanelController(ChangeViewer changeViewer, PrincipalViewer principalViewer, LeftContainerController leftContainerController, IntermediatePanel intermediatePanel, GameManager gameManager, UserManager userManager){
        this.principalViewer = principalViewer;
        this.intermediatePanel = intermediatePanel;
        this.leftContainerController = leftContainerController;
        this.changeViewer = changeViewer;
        this.gameManager = gameManager;
        this.userManager = userManager;

        intermediatePanel.actionPerform(this);
        intermediatePanel.getTable().addMouseListener(this);

    }
    /**
     * Configures the table in the IntermediatePanel to display relevant game information.
     * Clears the existing table contents and updates with current game data.
     */
    public void configurationOfTheTable() {

        intermediatePanel.clearTable();
        try {
            int currentUserId = userManager.getCurrentUserId();
            ArrayList<String> allUserId = gameManager.getAllGamesInfo("userId");//ESTAS FUNCIONES SON LAS QUE PETAN.
            ArrayList<String> allId = gameManager.getAllGamesInfo("id");
            ArrayList<String> allResourceCounter = gameManager.getAllGamesInfo("resourceCounter");
            ArrayList<String> allFinishedGames = gameManager.getAllGamesInfo("finishedGame");
            ArrayList<String> allGenerators = gameManager.getAllGamesInfo("ownedGenerators");
            ArrayList<String> allTotalProduction = gameManager.getAllGamesInfo("totalProduction");

            ArrayList<String> rowInfo = new ArrayList<>();

            for(int compt = 0; compt < allUserId.size(); compt++){
                if(allUserId.get(compt).equals(String.valueOf(currentUserId))){
                    if(allFinishedGames.get(compt).equals("false")) {
                        rowInfo.add(allId.get(compt));
                        rowInfo.add(allResourceCounter.get(compt));
                        rowInfo.add(allFinishedGames.get(compt));
                        rowInfo.add(String.valueOf(allGenerators.get(compt)));
                        rowInfo.add(allTotalProduction.get(compt));
                        intermediatePanel.addRow(rowInfo);
                        rowInfo = new ArrayList<>();
                    }
                }
            }

        } catch (BusinessException e) {
            intermediatePanel.showPopUp(e.getMessage());
        }
    }

    /**
     * Handles action events triggered by user interactions.
     *
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()){
            case Constants.START_ACTION:
                try{
                    principalViewer.changeView(Constants.START_ACTION);
                    gameManager.createNewGame(userManager.getCurrentUserId());
                    leftContainerController.addObserverToGameManager();
                    leftContainerController.setMacacoNumber(gameManager.getInitialMacacoNumber(gameManager.getCurrentGameId()));
                    intermediatePanel.addRow(gameManager.getLastGameInfo());
                } catch (BusinessException ex) {
                    intermediatePanel.showPopUp(ex.getMessage());
                }
                break;
            case Constants.OPTIONS_ACTION:
                principalViewer.changeView(Constants.OPTIONS_ACTION);
                break;
            case Constants.BEGIN_ACTION:
                userManager.logOut();
                principalViewer.dispose();
                changeViewer.startView();
                changeViewer.changeView(Constants.BEGIN_ACTION);
                break;
            default:
                break;
        }
    }

    /**
     * Handles mouse click events on the table in the IntermediatePanel.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        int row = intermediatePanel.getTable().rowAtPoint(e.getPoint());
        if (row >= 0) {
            Object gameIdObject = intermediatePanel.getTable().getValueAt(row, 0);
            if (gameIdObject != null) {
                int gameId = Integer.parseInt(gameIdObject.toString());
                try {
                    gameManager.enterGame(gameId);
                    leftContainerController.updateMacacoView();
                    leftContainerController.addObserverToGameManager();
                    principalViewer.changeView(Constants.START_ACTION);
                } catch (BusinessException ex) {
                    intermediatePanel.showPopUp(ex.getMessage());
                }
            }
        }
    }
    /**
     * Handles mouse press events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mousePressed(MouseEvent e) {

    }
    /**
     * Handles mouse release events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseReleased(MouseEvent e) {
    }

    /**
     * Handles mouse enter events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseEntered(MouseEvent e) {
    }

    /**
     * Handles mouse exit events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseExited(MouseEvent e) {
    }
}