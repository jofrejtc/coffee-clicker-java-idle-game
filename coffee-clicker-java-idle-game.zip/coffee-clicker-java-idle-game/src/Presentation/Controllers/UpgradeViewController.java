package Presentation.Controllers;

import Business.Managers.GameManager;
import Business.Managers.UpgradeManager;
import Exceptions.BusinessException;
import Exceptions.NoMoreMacacosException;
import Presentation.Views.UpgradeView;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
/**
 * Controller class for handling interactions with the UpgradeView.
 */
public class UpgradeViewController implements MouseListener {
    private final UpgradeView upgradeView;
    private final UpgradeManager upgradeManager;
    private final GameManager gameManager;
    private final LeftContainerController leftContainerController;

    /**
     * Constructs an UpgradeViewController with the specified dependencies.
     *
     * @param upgradeView           The UpgradeView instance associated with this controller.
     * @param gameManager           The GameManager instance for game-related operations.
     * @param upgradeManager        The UpgradeManager instance for upgrade-related operations.
     * @param leftContainerController The LeftContainerController instance for left container operations.
     */
    public UpgradeViewController(UpgradeView upgradeView, GameManager gameManager, UpgradeManager upgradeManager, LeftContainerController leftContainerController) {
        this.upgradeView = upgradeView;
        this.gameManager = gameManager;
        this.upgradeManager = upgradeManager;
        this.leftContainerController = leftContainerController;
        upgradeView.getTable().addMouseListener(this);
    }

    /**
     * Handles mouse click events on the upgrade view table.
     *
     * @param e The MouseEvent triggering the action.
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        int row = upgradeView.getTable().rowAtPoint(e.getPoint());
        int col = upgradeView.getTable().columnAtPoint(e.getPoint());
        if (row >= 0 && col > 0) {
            String generatorType = upgradeManager.getGeneratorType(row,col);
            double upgradeMultiplier = upgradeManager.getProductionMultiplier(row);
            float price = upgradeManager.getPrice(row,col);
            boolean okay = false;
            try {
                okay = gameManager.applyUpgrade(generatorType, upgradeMultiplier);
                gameManager.deleteMacacos(price);
                leftContainerController.setMacacoNumber(gameManager.getInitialMacacoNumber(gameManager.getCurrentGameId()));
                leftContainerController.updateMacacoView();
            } catch (BusinessException | NoMoreMacacosException k) {
                upgradeView.showPopUp(k.getMessage());
            }
            if (!okay) {
                upgradeView.showPopUp("There was a problem applying the upgrade.");
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}