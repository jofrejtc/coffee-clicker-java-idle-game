package Presentation.Controllers;

import Presentation.Views.JFrames.PrincipalViewer;
import Presentation.Views.StatsView;
import Presentation.Views.Tools.Constants;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * The StatsViewController class is responsible for handling actions in the StatsView.
 * It implements ActionListener to respond to action events from the view.
 */
public class StatsViewController implements ActionListener {

    private final PrincipalViewer principalViewer;
    /**
     * Constructs a StatsViewController with the specified dependencies.
     *
     * @param principalViewer The PrincipalViewer instance for main view operations.
     * @param statsView       The StatsView instance associated with this controller.
     */
    public StatsViewController(PrincipalViewer principalViewer, StatsView statsView){
        this.principalViewer = principalViewer;
        statsView.actionPerform(this);

    }
    /**
     * Performs the appropriate action based on the action command received.
     *
     * @param e The ActionEvent triggering the action.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals(Constants.START_ACTION)) {
            principalViewer.changeView(Constants.START_ACTION);
        }
    }
}
