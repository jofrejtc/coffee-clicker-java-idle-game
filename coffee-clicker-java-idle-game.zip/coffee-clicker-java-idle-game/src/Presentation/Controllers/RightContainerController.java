package Presentation.Controllers;

import Business.Managers.GameManager;
import Exceptions.BusinessException;
import Presentation.Views.PrincipalRightContainer;
import Presentation.Views.StartGameView;
import Presentation.Views.Tools.Constants;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Class that manages the controller of a JPanel Contained in the StartGameView.
 */
public class RightContainerController implements ActionListener {
    private final GameManager gameManager;
    private final StartGameView startGameView;
    private final PrincipalRightContainer principalRightContainer;
    private final CurrentGamesViewController currentGamesViewController;

    /**
     * Constructor of the controller for the view PrincipalRightContainer.
     *
     * @param startGameView View that contains the PrincipalRightContainer.
     * @param principalRightContainer View that is managed by this controller.
     * @param currentGamesViewController The controller for the current games view.
     * @param gameManager The manager for game-related operations.
     */
    public RightContainerController(StartGameView startGameView, PrincipalRightContainer principalRightContainer, CurrentGamesViewController currentGamesViewController, GameManager gameManager){
        this.startGameView = startGameView;
        this.principalRightContainer = principalRightContainer;
        this.currentGamesViewController = currentGamesViewController;
        this.gameManager = gameManager;
        principalRightContainer.actionPerform(this);
    }

    /**
     * Manages the actions that must occur when the buttons in this view are pressed.
     *
     * @param e The event to be processed.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            case Constants.SHOP_ACTION:
                startGameView.changePanel(Constants.SHOP_ACTION);
                break;
            case Constants.UPGRADE_ACTION:
                startGameView.changePanel(Constants.UPGRADE_ACTION);
                break;
            case Constants.CURRENT_ACTION:
                try {
                    gameManager.saveCurrentGame();
                } catch (BusinessException ex) {
                    principalRightContainer.showPopUp(ex.getMessage());
                }
                currentGamesViewController.configurationOfTheTable();
                startGameView.changePanel(Constants.CURRENT_ACTION);
                break;
            default:
                break;
        }
    }
}