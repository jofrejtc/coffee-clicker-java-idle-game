package Presentation.Controllers;

import Business.Managers.GameManager;
import Exceptions.BusinessException;
import Exceptions.LogOutException;
import Presentation.Views.JFrames.ChangeViewer;
import Presentation.Views.JFrames.PrincipalViewer;
import Presentation.Views.OptionsView;
import Business.Managers.UserManager;
import Presentation.Views.Tools.Constants;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * Controller for managing the OptionsView.
 */
public class OptionsController implements ActionListener {
    private final PrincipalViewer principalViewer;
    private final OptionsView optionsView;
    private final UserManager userManager;
    private final GameManager gameManager;

    private final ChangeViewer changeViewer;
    private final IntermediatePanelController intermediatePanelController;
    private final LeftContainerController leftContainerController;
    /**
     * Constructs an OptionsController with the specified dependencies.
     * Initializes necessary components and sets up action listeners.
     *
     * @param principalViewer           The PrincipalViewer instance for main view operations.
     * @param optionsView               The OptionsView instance associated with this controller.
     * @param userManager               The UserManager instance for user-related operations.
     * @param gameManager               The GameManager instance for game-related operations.
     * @param changeViewer              The ChangeViewer instance for changing views.
     * @param intermediatePanelController The IntermediatePanelController instance for intermediate panel operations.
     * @param leftContainerController   The LeftContainerController instance for left container operations.
     */
    public OptionsController(PrincipalViewer principalViewer, OptionsView optionsView, UserManager userManager,GameManager gameManager, ChangeViewer changeViewer, IntermediatePanelController intermediatePanelController, LeftContainerController leftContainerController) {
        this.principalViewer = principalViewer;
        this.optionsView = optionsView;
        this.userManager = userManager;
        this.gameManager = gameManager;

        this.changeViewer = changeViewer;
        this.intermediatePanelController = intermediatePanelController;
        this.leftContainerController = leftContainerController;
        this.optionsView.actionPerform(this);
    }

    /**
     * Performs the appropriate action based on the action command received.
     *
     * @param e The ActionEvent triggering the action.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        switch (command) {
            case Constants.START_ACTION:
                handleExit();
                break;
            case Constants.INTERMEDIATE_ACTION:
                handleMenu();
                break;
            case Constants.BEGIN_ACTION:
                if(!handleLogOut()){
                    optionsView.showPopUp("No user is currently logged in.");
                }
                break;
            case Constants.DELETE_ACTION:
                handleDeleteAccount();
                break;
            default:
        }
    }

    /**
     * Handles the action for exiting the options menu.
     */
    private void handleExit() {
        principalViewer.changeView(Constants.START_ACTION);
    }

    /**
     * Handles the action for navigating to the intermediate menu.
     */
    private void handleMenu() {

        try {
            gameManager.stopAllThreads();
            gameManager.saveCurrentGame();
        } catch (BusinessException e) {
            optionsView.showPopUp(e.getMessage());
        }
        leftContainerController.clearGeneratorTable();
        intermediatePanelController.configurationOfTheTable();
        principalViewer.changeView(Constants.INTERMEDIATE_ACTION);
    }

    /**
     * Handles the action for logging out the current user.
     *
     * @return True if logout was successful, otherwise false.
     */
    private boolean handleLogOut() {
        boolean correctLogOut;
        if(userManager.logOut()){
            try {
                gameManager.stopAllThreads();
                gameManager.saveCurrentGame();
            } catch (BusinessException e) {
                optionsView.showPopUp(e.getMessage());
            }
            optionsView.showPopUp("The user logged out successfully.");
            leftContainerController.clearGeneratorTable();
            correctLogOut = true;
        } else{
            optionsView.showPopUp("No user is currently logged in.");
            correctLogOut = false;
        }
        principalViewer.dispose();
        changeViewer.startView();
        changeViewer.changeView(Constants.BEGIN_ACTION);
        return correctLogOut;
    }

    /**
     * Handles the action for deleting the user account.
     */
    private void handleDeleteAccount() {
        String username = JOptionPane.showInputDialog(principalViewer, "Please enter your username for verification:");
        boolean success = false;
        if (username != null && !username.isEmpty()) {
            try{
                success = gameManager.deleteUserGames(userManager.getCurrentUserId());
                if(success) {
                    success = userManager.deleteAccount();
                }
                if(!success){
                    optionsView.showPopUp("No user is currently logged in");
                }
            } catch (LogOutException | BusinessException e){
                optionsView.showPopUp(e.getMessage());
            }
            if (success) {
                optionsView.showPopUp("Account deleted successfully.");
                try {
                    gameManager.stopAllThreads();
                    gameManager.saveCurrentGame();
                } catch (BusinessException e) {
                    optionsView.showPopUp(e.getMessage());
                }
                principalViewer.dispose();
                changeViewer.startView();
                changeViewer.changeView(Constants.BEGIN_ACTION);
            } else {
                optionsView.showPopUp("Account deletion failed.");
            }
        }
    }
}