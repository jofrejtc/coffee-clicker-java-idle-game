package Presentation.Controllers;

import Business.Managers.UserManager;
import Exceptions.LogInException;
import Presentation.Views.JFrames.ChangeViewer;
import Presentation.Views.LoginView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Presentation.Views.JFrames.PrincipalViewer;
import Presentation.Views.Tools.Constants;


/**
 * Controller of the view LoginView.
 */
public class LoginController implements ActionListener {
    private final ChangeViewer changeViewer;
    private final PrincipalViewer principalViewer;
    private final UserManager userManager;
    private final LoginView loginView;
    private final IntermediatePanelController intermediatePanelController;

    /**
     * Constructor of the controller of the view LoginView.
     * @param changeViewer JFrame that has the LoginView.
     * @param principalViewer JFrame that has some of the views where you will go from the LoginView.
     * @param loginView View that is managed in this controller.
     * @param userManager Manager that gets works with the information of the users.
     * @param intermediatePanelController controller of the intermediatePanel Controller.
     */
    public LoginController(ChangeViewer changeViewer, PrincipalViewer principalViewer, LoginView loginView, UserManager userManager, IntermediatePanelController intermediatePanelController){
        this.loginView = loginView;
        this.userManager = userManager;
        loginView.actionPerform(this);
        this.principalViewer = principalViewer;
        this.changeViewer = changeViewer;
        this.intermediatePanelController = intermediatePanelController;
    }

    /**
     * Method used to perform all the actions  related with the login view
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case Constants.BEGIN_ACTION:
                changeViewer.changeView(Constants.BEGIN_ACTION);
                loginView.clearFields();
                break;
            case Constants.INTERMEDIATE_ACTION:
                String credentials = loginView.getUsernameData();
                String password = loginView.getPasswordData();
                boolean isLoginSuccess = false;
                try {
                    isLoginSuccess = userManager.logIn(credentials,password);
                    loginView.clearFields();
                } catch (LogInException ex) {
                    loginView.showPopUp(ex.getMessage());
                    loginView.clearFields();
                }
                if(isLoginSuccess){
                    changeViewer.dispose();
                    principalViewer.startView();
                    principalViewer.changeView(Constants.INTERMEDIATE_ACTION);
                    loginView.clearFields();
                    intermediatePanelController.configurationOfTheTable();
                }
                else{
                    loginView.showPopUp("Credenciales incorrectas. Por favor, inténtelo de nuevo.");
                    loginView.clearFields();
                }
                break;
            default:
                break;
        }
    }
}