package Presentation.Controllers;

import Exceptions.BusinessException;
import Business.Managers.GameManager;
import Business.Managers.UserManager;
import Presentation.Views.FinishedGamesView;
import Presentation.Views.JFrames.PrincipalViewer;
import Presentation.Views.Tools.Constants;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
/**
 * The FinishedGamesController class controls the behavior of the FinishedGamesView.
 * It implements ActionListener to handle action events and MouseListener to handle mouse events on the view.
 */
public class FinishedGamesController implements ActionListener, MouseListener {
    private final PrincipalViewer principalViewer;
    private final FinishedGamesView finishedGamesView;
    private final GameManager gameManager;
    private final UserManager userManager;
    private final LeftContainerController leftContainerController;
    private final IntermediatePanelController intermediatePanelController;
    /**
     * Constructs a FinishedGamesController object with the specified views and managers.
     * @param principalViewer The main frame of the application.
     * @param finishedGamesView The view for finished games.
     * @param gameManager The game manager.
     * @param userManager The user manager.
     * @param leftContainerController The controller for the left container.
     * @param intermediatePanelController The controller for the intermediate panel.
     */
    public FinishedGamesController(PrincipalViewer principalViewer, FinishedGamesView finishedGamesView, GameManager gameManager, UserManager userManager, LeftContainerController leftContainerController, IntermediatePanelController intermediatePanelController){
        this.principalViewer = principalViewer;
        this.finishedGamesView = finishedGamesView;
        this.gameManager = gameManager;
        this.userManager = userManager;
        this.leftContainerController = leftContainerController;
        this.intermediatePanelController = intermediatePanelController;
        finishedGamesView.actionPerform(this);
        finishedGamesView.getTable().addMouseListener(this);
    }
    /**
     * Handles action events triggered by user interactions.
     *
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()){
            case Constants.START_ACTION:
                principalViewer.changeView(Constants.START_ACTION);
                break;
            case Constants.OPTIONS_ACTION:
                principalViewer.changeView(Constants.OPTIONS_ACTION);
                break;
            case Constants.FINISH_ACTUAL_ACTION:
                try {
                    gameManager.stopAllThreads();
                    gameManager.finishActualGame();
                    gameManager.saveCurrentGame();
                    leftContainerController.clearGeneratorTable();
                    intermediatePanelController.configurationOfTheTable();
                    finishedGamesView.showPopUp("Congratulations :)\n this game finished!!");
                    principalViewer.changeView(Constants.INTERMEDIATE_ACTION);
                } catch (BusinessException ex) {
                    finishedGamesView.showPopUp(ex.getMessage());
                }
                break;
            default:
                break;
        }

    }
    /**
     * Configures the table with the finished games information.
     */
    public void configurationOfTheTable() {
        finishedGamesView.clearTable();
        try {
            int currentUserId = userManager.getCurrentUserId();
            ArrayList<String> allUserId = gameManager.getAllGamesInfo("userId");
            ArrayList<String> allId = gameManager.getAllGamesInfo("id");
            ArrayList<String> allResourceCounter = gameManager.getAllGamesInfo("resourceCounter");
            ArrayList<String> allFinishedGames = gameManager.getAllGamesInfo("finishedGame");
            ArrayList<String> allGenerators = gameManager.getAllGamesInfo("ownedGenerators");
            ArrayList<String> allTotalProduction = gameManager.getAllGamesInfo("totalProduction");
            ArrayList<String> rowInfo = new ArrayList<>();
            for(int compt = 0; compt < allUserId.size(); compt++){
                if(allUserId.get(compt).equals(String.valueOf(currentUserId))){
                    if(allFinishedGames.get(compt).equals("true")){
                        rowInfo.add(allId.get(compt));
                        rowInfo.add(allResourceCounter.get(compt));
                        rowInfo.add(allFinishedGames.get(compt));
                        rowInfo.add(String.valueOf(allGenerators.get(compt)));
                        rowInfo.add(allTotalProduction.get(compt));
                        finishedGamesView.addRow(rowInfo);
                        rowInfo = new ArrayList<>();
                    }
                }
            }

        } catch (BusinessException e) {
            finishedGamesView.showPopUp(e.getMessage());
        }
    }

    /**
     * Handles mouse press events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        int row = finishedGamesView.getTable().rowAtPoint(e.getPoint());
        if (row >= 0) {
            principalViewer.changeView(Constants.STATS_ACTION);
        }
    }
    /**
     * Handles mouse press events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mousePressed(MouseEvent e) {
    }

    /**
     * Handles mouse release events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseReleased(MouseEvent e) {
    }

    /**
     * Handles mouse enter events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseEntered(MouseEvent e) {
    }

    /**
     * Handles mouse exit events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseExited(MouseEvent e) {
    }

}
