package Presentation.Controllers;

import Business.Entities.Game;
import Exceptions.BusinessException;
import Business.Managers.GameManager;
import Presentation.Views.PrincipalLeftContainer;
import Presentation.Views.Tools.Constants;
import java.awt.event.*;
import java.util.ArrayList;
/**
 * The LeftContainerController class handles actions in the PrincipalLeftContainer view
 * and updates the view based on changes in the game state.
 */
public class LeftContainerController implements ActionListener {
    private final PrincipalLeftContainer principalLeftContainer;
    private final GameManager gameManager;

    /**
     * Constructs a LeftContainerController with the specified dependencies.
     * Initializes necessary components and sets up event listeners.
     *
     * @param principalLeftContainer The PrincipalLeftContainer instance associated with this controller.
     * @param gameManager            The GameManager instance for game-related operations.
     */
    public LeftContainerController(PrincipalLeftContainer principalLeftContainer, GameManager gameManager){
        this.principalLeftContainer = principalLeftContainer;
        this.gameManager = gameManager;
        principalLeftContainer.actionPerform(this);
        addObserverToGameManager();
    }
    /**
     * Handles the action event triggered by the view's buttons.
     * Increases the number of macacos when the macaco action is performed.
     *
     * @param e The ActionEvent triggering the action.
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getActionCommand().equals(Constants.MACACO_ACTION)) {
            try {
                Game updatedGame = gameManager.increaseMacacosWithTheClick();
                if (updatedGame != null) {
                    float updatedMacacoNumber = gameManager.getInitialMacacoNumber(gameManager.getCurrentGameId());
                    principalLeftContainer.setMacacoNumber(updatedMacacoNumber);
                }
            } catch (BusinessException k) {
                principalLeftContainer.showPopUp(k.getMessage());
            }
        }
    }

    /**
     * Sets the initial macaco number in the left container view.
     *
     * @param initialMacacoNumber The initial macaco number to be set in the view.
     */
    public void setMacacoNumber(float initialMacacoNumber) {
        principalLeftContainer.setMacacoNumber(initialMacacoNumber);
    }

    /**
     * Updates the macaco view with the latest macaco number and generator information.
     *
     */
    public void updateMacacoView() {
        try {
            principalLeftContainer.setMacacoNumber(gameManager.getInitialMacacoNumber(gameManager.getCurrentGameId()));
        } catch (BusinessException e) {
            principalLeftContainer.showPopUp(e.getMessage());
        }
        clearGeneratorTable();
        ArrayList<String> currentGeneratorsInfo = null;
        try {
            currentGeneratorsInfo = gameManager.currentGeneratorsInfoForMacacoTable();
        } catch (BusinessException e) {
            principalLeftContainer.showPopUp(e.getMessage());
        }

        int numberOfGeneratorsToAdd = 0;
        if (currentGeneratorsInfo != null) {
            numberOfGeneratorsToAdd = currentGeneratorsInfo.size()/4;
        }
        for (int compt = 0; compt < numberOfGeneratorsToAdd; compt++) {
            int startIndex = compt * 5;
            String[] rowData = new String[5];
            for (int i = 0; i < 5; i++) {
                rowData[i] = currentGeneratorsInfo.get(startIndex + i);
            }
            addNewRow(rowData);
        }
    }

    /**
     * Clears the generator table in the left container view.
     */
    public void clearGeneratorTable(){
        principalLeftContainer.clearTable();
    }

    /**
     * Adds a new row to the generator table in the left container view.
     *
     * @param rowData The data for the new row.
     */
    public void addNewRow(Object[] rowData) {
        principalLeftContainer.addRow(rowData);
    }

    /**
     * Adds an observer to the GameManager to update the macaco number in the view.
     */
    public void addObserverToGameManager() {
        this.gameManager.addObserver(new GameObserver() {
            @Override
            public void updateMacacoNumber(float macacoNumber) {
                setMacacoNumber(macacoNumber);
            }
        });
    }
}