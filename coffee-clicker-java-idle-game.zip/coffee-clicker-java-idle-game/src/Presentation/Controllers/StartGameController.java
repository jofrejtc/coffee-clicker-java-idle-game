package Presentation.Controllers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Presentation.Views.JFrames.PrincipalViewer;
import Presentation.Views.StartGameView;
import Presentation.Views.Tools.Constants;

/**
 * Controller of the StartGameView of the game.
 */
public class StartGameController implements ActionListener {
    private final PrincipalViewer principalViewer;
    private final FinishedGamesController finishedGamesController;
    /**
     * Constructor of the controller that manages the StartGameView.
     * @param principalViewer jframe that contains the view start game
     * @param startGameView view that is managed in this controller
     * @param finishedGamesController controller for finished games.
     */
    public StartGameController(PrincipalViewer principalViewer, StartGameView startGameView, FinishedGamesController finishedGamesController){
        this.principalViewer = principalViewer;
        this.finishedGamesController = finishedGamesController;
        startGameView.actionPerform(this);
    }
    /**
     * We manage the buttons from the StartGameView.
     * @param e the event to be processed.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            case Constants.OPTIONS_ACTION:
                principalViewer.changeView(Constants.OPTIONS_ACTION);
                break;
            case Constants.FINISHED_ACTION:
                finishedGamesController.configurationOfTheTable();
                principalViewer.changeView(Constants.FINISHED_ACTION);
                break;


            default:
                break;
        }
    }
}
