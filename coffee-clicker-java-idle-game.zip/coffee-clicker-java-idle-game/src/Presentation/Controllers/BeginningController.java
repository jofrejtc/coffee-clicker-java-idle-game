package Presentation.Controllers;

import Presentation.Views.BeginningPanel;
import Presentation.Views.JFrames.ChangeViewer;
import Presentation.Views.Tools.Constants;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Class that manages the Actions of the view BeginningPanel.
 */
public class BeginningController implements ActionListener {
    private final ChangeViewer changeViewer;
    //BeginningPanel beginningPanel;

    /**
     * Constructor of the view BeginningController.
     * @param changeViewer JFrame that contains the JPanel.
     * @param beginningPanel JPanel managed by this controller.
     */

    public BeginningController(ChangeViewer changeViewer, BeginningPanel beginningPanel) {
        this.changeViewer = changeViewer;
        beginningPanel.actionPerform(this);
        changeViewer.startView();
    }
    /**
     * Method that configures the actions of the view BeginningPanel when the buttons are pushed.
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case Constants.LOGIN_ACTION:
                changeViewer.changeView(Constants.LOGIN_ACTION);
                break;
            case Constants.SIGN_UP_ACTION:
                changeViewer.changeView(Constants.SIGN_UP_ACTION);
                break;
            default:
                break;
        }
    }

}
