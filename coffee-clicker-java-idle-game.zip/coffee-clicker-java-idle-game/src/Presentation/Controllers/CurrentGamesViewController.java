package Presentation.Controllers;

import Business.Managers.GameManager;
import Business.Managers.UserManager;
import Exceptions.BusinessException;
import Presentation.Views.CurrentGamesView;
import Presentation.Views.JFrames.PrincipalViewer;
import Presentation.Views.Tools.Constants;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

/**
 * The CurrentGamesViewController class controls the behavior of the CurrentGamesView.
 * It implements MouseListener to handle mouse events on the view.
 */
public class CurrentGamesViewController implements MouseListener {
    private final PrincipalViewer principalViewer;
    private final CurrentGamesView currentGamesView;
    private final GameManager gameManager;
    private final UserManager userManager;

    /**
     * Constructs a CurrentGamesViewController object with the specified views and managers.
     * @param principalViewer The main frame of the application.
     * @param currentGamesView The view for current games.
     * @param gameManager The game manager.
     * @param userManager The user manager.
     */
    public CurrentGamesViewController(PrincipalViewer principalViewer, CurrentGamesView currentGamesView,  GameManager gameManager, UserManager userManager) {
        this.principalViewer = principalViewer;
        this.currentGamesView = currentGamesView;
        this.userManager = userManager;
        this.gameManager = gameManager;
        currentGamesView.getTable().addMouseListener(this);
    }

    /**
     * Configures the table with the current games information.
     */
    public void configurationOfTheTable() {

        currentGamesView.clearTable();

        try{
            int currentUserId = userManager.getCurrentUserId();
            ArrayList<String> allUserId = gameManager.getAllGamesInfo("userId");
            ArrayList<String> allId = gameManager.getAllGamesInfo("id");
            ArrayList<String> allResourceCounter = gameManager.getAllGamesInfo("resourceCounter");
            ArrayList<String> allFinishedGames = gameManager.getAllGamesInfo("finishedGame");
            ArrayList<String> allGenerators = gameManager.getAllGamesInfo("ownedGenerators");
            ArrayList<String> allTotalProduction = gameManager.getAllGamesInfo("totalProduction");
            ArrayList<String> rowInfo = new ArrayList<>();
            for(int compt = 0; compt < allUserId.size(); compt++){
                if(allUserId.get(compt).equals(String.valueOf(currentUserId))){
                    if(allFinishedGames.get(compt).equals("false")){
                        rowInfo.add(allId.get(compt));
                        rowInfo.add(allResourceCounter.get(compt));
                        rowInfo.add(allFinishedGames.get(compt));
                        rowInfo.add(String.valueOf(allGenerators.get(compt)));
                        rowInfo.add(allTotalProduction.get(compt));
                        currentGamesView.addRow(rowInfo);
                        rowInfo = new ArrayList<>();
                    }
                }
            }
        } catch (BusinessException e) {
            currentGamesView.showPopUp(e.getMessage());
        }
    }

    /**
     * Handles mouse click events on the table in the CurrentGamesView.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        int row = currentGamesView.getTable().rowAtPoint(e.getPoint());
        if (row >= 0) {
            principalViewer.changeView(Constants.STATS_ACTION);

        }
    }
    /**
     * Handles mouse press events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mousePressed(MouseEvent e) {
    }

    /**
     * Handles mouse release events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseReleased(MouseEvent e) {
    }

    /**
     * Handles mouse enter events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseEntered(MouseEvent e) {
    }

    /**
     * Handles mouse exit events.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseExited(MouseEvent e) {
    }
}
