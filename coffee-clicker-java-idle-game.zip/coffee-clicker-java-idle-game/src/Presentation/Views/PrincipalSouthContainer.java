package Presentation.Views;

import Presentation.Views.Tools.Constants;

import javax.swing.*;
import java.awt.*;

/**
 * Class that configures the south of the principal container.
 */
public class PrincipalSouthContainer extends JPanel {

    /**
     * Constructs the PrincipalSouthContainer.
     *
     * @param optionsButton   The options button.
     * @param finishGameButton The finish game button.
     */
    public PrincipalSouthContainer(JButton optionsButton, JButton finishGameButton) {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 40, 10));
        buttonPanel.setBackground(Constants.MARRO_FONDO);
        setLayout(new BorderLayout());

        buttonPanel.add(optionsButton);
        buttonPanel.add(finishGameButton);
        add(buttonPanel, BorderLayout.CENTER);
    }
}