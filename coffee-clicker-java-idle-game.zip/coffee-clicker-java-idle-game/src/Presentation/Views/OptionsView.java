package Presentation.Views;

import Presentation.Views.Tools.Constants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Class that shows the options menu.
 */
public class OptionsView extends JPanel {
    private final JButton exitButton;
    private final JButton menuButton;
    private final JButton logoutButton;
    private final JButton deleteAccountButton;

    /**
     * Constructs the OptionsView.
     */
    public OptionsView() {

        setBackground(Constants.MARRO_FONDO);
        setLayout(new BorderLayout());

        JLabel topLabel = new JLabel("OPTIONS");
        topLabel.setFont(new Font("Arial", Font.BOLD, 30));
        topLabel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        topLabel.setForeground(Constants.ORANGE_COLOR);
        topLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(topLabel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        centerPanel.setBackground(Constants.MARRO_FONDO);

        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 30, 30));
        buttonPanel.setBackground(Constants.MARRO_FONDO);
        buttonPanel.setPreferredSize(new Dimension(400, 200));

        exitButton = new JButton("EXIT");
        exitButton.setFont(new Font("Arial", Font.BOLD, 16));
        exitButton.setBackground(Constants.BUTTON_COLOR);
        exitButton.setForeground(Constants.MARRO_FONDO);
        buttonPanel.add(exitButton);

        menuButton = new JButton("MENU");
        menuButton.setFont(new Font("Arial", Font.BOLD, 16));
        menuButton.setBackground(Constants.BUTTON_COLOR);
        menuButton.setForeground(Constants.MARRO_FONDO);
        buttonPanel.add(menuButton);

        logoutButton = new JButton("LOG OUT");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 16));
        logoutButton.setBackground(Constants.BUTTON_COLOR);
        logoutButton.setForeground(Constants.MARRO_FONDO);
        buttonPanel.add(logoutButton);

        deleteAccountButton = new JButton("DELETE ACCOUNT");
        deleteAccountButton.setFont(new Font("Arial", Font.BOLD, 16));
        deleteAccountButton.setBackground(Constants.BUTTON_COLOR);
        deleteAccountButton.setForeground(Constants.MARRO_FONDO);
        deleteAccountButton.setPreferredSize(new Dimension(150, 30));
        buttonPanel.add(deleteAccountButton);

        centerPanel.add(buttonPanel, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);
    }

    /**
     * Adds ActionListener to the buttons.
     *
     * @param actionListener The ActionListener to be added to the buttons.
     */
    public void actionPerform(ActionListener actionListener) {
        exitButton.setActionCommand(Constants.START_ACTION);
        menuButton.setActionCommand(Constants.INTERMEDIATE_ACTION);
        logoutButton.setActionCommand(Constants.BEGIN_ACTION);
        deleteAccountButton.setActionCommand(Constants.DELETE_ACTION);
        exitButton.addActionListener(actionListener);
        menuButton.addActionListener(actionListener);
        logoutButton.addActionListener(actionListener);
        deleteAccountButton.addActionListener(actionListener);
    }

    /**
     * Method that displays a popup message.
     *
     * @param message The message to be displayed.
     */
    public void showPopUp(String message) {
        JOptionPane.showMessageDialog(null, message);
    }
}
