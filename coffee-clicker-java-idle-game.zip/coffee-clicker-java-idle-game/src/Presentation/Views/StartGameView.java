package Presentation.Views;

import Presentation.Views.Tools.Constants;
import Presentation.Views.Tools.TableBorderLayout;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * The StartGameView class configures the JPanel that contains the StartGameView.
 */
public class StartGameView extends JPanel {

    private final JButton optionsButton;
    private final JButton finishGameButton;
    private final TableBorderLayout tableBorderLayout;

    /**
     * Constructor of the StartGameView.
     * @param tableBorderLayout The BorderLayout that configures the CardLayout of the tables in the view.
     * @param principalRightContainer The container that has the JPanels inside the part in the right of the view.
     * @param principalLeftContainer The container that has the JPanels inside the part in the left of the view.
     */
    public StartGameView(TableBorderLayout tableBorderLayout, PrincipalRightContainer principalRightContainer, PrincipalLeftContainer principalLeftContainer) {
        setBackground(Constants.MARRO_FONDO);
        setLayout(new BorderLayout());
        this.tableBorderLayout = tableBorderLayout;

        optionsButton = new JButton("OPTIONS");
        optionsButton.setBackground(Constants.BUTTON_COLOR);
        optionsButton.setForeground(Constants.MARRO_FONDO);
        optionsButton.setFont(new Font("Arial", Font.BOLD, 16));
        optionsButton.setPreferredSize(new Dimension(150, 50));

        finishGameButton = new JButton("YOUR FINISHED GAMES");
        finishGameButton.setBackground(Constants.BUTTON_COLOR);
        finishGameButton.setForeground(Constants.MARRO_FONDO);
        finishGameButton.setFont(new Font("Arial", Font.BOLD, 16));
        finishGameButton.setPreferredSize(new Dimension(300, 50));

        JPanel centralPanel = new JPanel();
        centralPanel.setBackground(Constants.MARRO_FONDO);
        centralPanel.setLayout(new GridLayout(1, 2));
        PrincipalSouthContainer principalSouthContainer = new PrincipalSouthContainer(optionsButton, finishGameButton);

        centralPanel.add(principalLeftContainer);
        centralPanel.add(principalRightContainer);
        add(centralPanel, BorderLayout.CENTER);
        add(principalSouthContainer, BorderLayout.SOUTH);
    }

    /**
     * Manages the listeners of the buttons.
     * @param listener The listener used in the view.
     */
    public void actionPerform(ActionListener listener) {
        optionsButton.setActionCommand(Constants.OPTIONS_ACTION);
        finishGameButton.setActionCommand(Constants.FINISHED_ACTION);
        optionsButton.addActionListener(listener);
        finishGameButton.addActionListener(listener);
    }

    /**
     * Changes the JTable inside the BorderLayout.
     * @param index The index.
     */
    public void changePanel(String index) {
        tableBorderLayout.getPrincipalCardLayout().show(tableBorderLayout.getPrincipalBorderLayout(), index);
        tableBorderLayout.revalidate();
        tableBorderLayout.repaint();
    }
}