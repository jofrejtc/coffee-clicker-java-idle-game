package Presentation.Views;

import Presentation.Views.Tools.Constants;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * The ShopView class represents the view for displaying the shop.
 */
public class ShopView extends JPanel {

    private final DefaultTableModel tableModel;
    private final JTable table;
    private int costBaseA = 10, costBaseB = 150, costBaseC = 2000;

    /**
     * Constructs a new ShopView.
     */
    public ShopView() {

        setBackground(Constants.MARRO_FONDO);
        String[] column = {"Generator Type", "Base Cost", "Base Production", "Cost Increment"};

        tableModel = new DefaultTableModel(column, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        Object[][] data = {
                {"A", costBaseA, 0.2, 1.07},
                {"B", costBaseB, 1.0, 1.15},
                {"C", costBaseC, 15.0, 1.12}
        };
        for (Object[] row : data) {
            tableModel.addRow(row);
        }

        table = new JTable(tableModel);
        table.setAutoCreateRowSorter(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(200, 200));

        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(20, 20, 20, 20));
        add(scrollPane, BorderLayout.CENTER);
        setVisible(true);
    }

    /**
     * Adds an ActionListener to components of ShopView if needed in the future.
     *
     */
    public void actionPerform() {
    }

    /**
     * Retrieves the table component.
     *
     * @return The table component.
     */
    public JTable getTable() {
        JViewport viewport = (JViewport) ((JScrollPane) getComponent(0)).getComponent(0);
        return (JTable) viewport.getView();
    }

    /**
     * Retrieves the index of the currently selected row in the table.
     *
     * @return The index of the currently selected row, or -1 if no row is selected.
     */
    public int getSelectedRowIndex() {
        if (table != null) {
            return table.getSelectedRow();
        } else {
            return -1;
        }
    }

    /**
     * Displays a pop-up message.
     *
     * @param message The message to be displayed.
     */
    public void showPopUp(String message) {
        JOptionPane.showMessageDialog(null, message);
    }

    /**
     * Sets the base cost for Generator Type A.
     *
     * @param costBaseA The new base cost for Generator Type A.
     */
    public void setCostBaseA(int costBaseA) {
        this.costBaseA = costBaseA;
        tableModel.setValueAt(costBaseA, 0, 1);
        this.revalidate();
        this.repaint();
    }

    /**
     * Sets the base cost for Generator Type B.
     *
     * @param costBaseB The new base cost for Generator Type B.
     */
    public void setCostBaseB(int costBaseB) {
        this.costBaseB = costBaseB;
        tableModel.setValueAt(costBaseB, 1, 1);
        this.revalidate();
        this.repaint();
    }

    /**
     * Sets the base cost for Generator Type C.
     *
     * @param costBaseC The new base cost for Generator Type C.
     */
    public void setCostBaseC(int costBaseC) {
        this.costBaseC = costBaseC;
        tableModel.setValueAt(costBaseC, 2, 1);
        this.revalidate();
        this.repaint();
    }
}
