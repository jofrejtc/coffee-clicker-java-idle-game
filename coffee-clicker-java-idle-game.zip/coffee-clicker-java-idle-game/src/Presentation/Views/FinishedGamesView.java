package Presentation.Views;

import Presentation.Views.Tools.Constants;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Class that displays the table of the finished games.
 */
public class FinishedGamesView extends JPanel {

    private final JButton optionsButton;
    private final JButton backButton;
    private final JButton finishGameButton;
    private final DefaultTableModel tableModel;

    /**
     * Constructs the FinishedGamesView.
     */
    public FinishedGamesView(){

        setBackground(Constants.MARRO_FONDO);
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

        tableModel = new DefaultTableModel(
                new Object[][]{},
                new String[]{"GameId", "Resource Counter", "Finished", "generators", "production"}
        );

        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(200, 200));

        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 30, 0));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        buttonPanel.setBackground(Constants.MARRO_FONDO);

        optionsButton = new JButton("OPTIONS");
        optionsButton.setFont(new Font("Arial", Font.BOLD, 16));
        optionsButton.setBackground(Constants.BUTTON_COLOR);
        optionsButton.setForeground(Constants.MARRO_FONDO);

        backButton = new JButton("BACK");
        backButton.setFont(new Font("Arial", Font.BOLD, 16));
        backButton.setBackground(Constants.BUTTON_COLOR);
        backButton.setForeground(Constants.MARRO_FONDO);

        finishGameButton = new JButton("FINISH ACTUAL GAME");
        finishGameButton.setFont(new Font("Arial", Font.BOLD, 16));
        finishGameButton.setBackground(Constants.BUTTON_COLOR);
        finishGameButton.setForeground(Constants.MARRO_FONDO);

        buttonPanel.add(backButton);
        buttonPanel.add(optionsButton);
        buttonPanel.add(finishGameButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Adds ActionListener to the buttons.
     *
     * @param actionListener The ActionListener to be added to the buttons.
     */
    public void actionPerform(ActionListener actionListener) {

        optionsButton.setActionCommand(Constants.OPTIONS_ACTION);
        backButton.setActionCommand(Constants.START_ACTION);
        finishGameButton.setActionCommand(Constants.FINISH_ACTUAL_ACTION);

        optionsButton.addActionListener(actionListener);
        backButton.addActionListener(actionListener);
        finishGameButton.addActionListener(actionListener);
    }

    /**
     * Adds a new row to the table.
     *
     * @param rowData The data to be added as a row to the table.
     */
    public void addRow(ArrayList<String> rowData) {
        Object[] rowArray = rowData.toArray();
        tableModel.addRow(rowArray);
    }

    /**
     * Gets the table of the view.
     *
     * @return The JTable component contained within the JScrollPane viewport.
     */
    public JTable getTable() {
        JViewport viewport = (JViewport) ((JScrollPane) getComponent(0)).getComponent(0);
        return (JTable) viewport.getView();
    }

    /**
     * Clears all rows from the table.
     */
    public void clearTable() {
        tableModel.setRowCount(0);
    }

    /**
     * Displays a popup message.
     *
     * @param message The message to be displayed.
     */
    public void showPopUp(String message) {
        JOptionPane.showMessageDialog(null, message);
    }
}

