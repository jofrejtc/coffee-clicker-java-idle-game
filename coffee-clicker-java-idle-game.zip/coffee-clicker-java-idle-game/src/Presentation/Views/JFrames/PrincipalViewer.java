package Presentation.Views.JFrames;

import Presentation.Views.*;
import Presentation.Views.Tools.Constants;
import Presentation.Views.Tools.ImagePanel;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
/**
 * JFrame that serves as the main window for the application.
 */
public class PrincipalViewer extends JFrame {
    private final StartGameView startGameView;
    private final OptionsView optionsView;
    private final StatsView statsView;
    private final FinishedGamesView finishedGamesView;
    private final IntermediatePanel intermediatePanel;
    private final JPanel principalBorderLayout;
    private final CardLayout principalCardLayout;

    /**
     * Constructs a PrincipalViewer object with the specified views.
     * @param startGameView The view for starting a game.
     * @param optionsView The options view.
     * @param statsView The statistics view.
     * @param finishedGamesView The view for finished games.
     * @param intermediatePanel The intermediate panel.
     */
    public PrincipalViewer(StartGameView startGameView, OptionsView optionsView, StatsView statsView, FinishedGamesView finishedGamesView, IntermediatePanel intermediatePanel){
        this.startGameView = startGameView;
        this.optionsView = optionsView;
        this.statsView = statsView;
        this.finishedGamesView = finishedGamesView;
        this.intermediatePanel = intermediatePanel;
        principalCardLayout = new CardLayout();
        principalBorderLayout = new JPanel(principalCardLayout);
        configureWindow();
        configureView();
    }

    /**
     * Configures the views and layout of the main frame.
     */
    private void configureView() {
        ImagePanel backgroundPanel = new ImagePanel("files/Images/Macacos.jpg");
        backgroundPanel.setLayout(new BorderLayout());

        principalBorderLayout.add(intermediatePanel, Constants.INTERMEDIATE_ACTION);
        principalBorderLayout.add(startGameView, Constants.START_ACTION);
        principalBorderLayout.add(optionsView, Constants.OPTIONS_ACTION);
        principalBorderLayout.add(statsView, Constants.STATS_ACTION);
        principalBorderLayout.add(finishedGamesView, Constants.FINISHED_ACTION);

        JPanel infoCentral = new JPanel(new BorderLayout());
        infoCentral.setOpaque(false);
        infoCentral.add(principalBorderLayout, BorderLayout.CENTER);
        infoCentral.setBorder(new EmptyBorder(80,30,40,30));

        backgroundPanel.add(infoCentral, BorderLayout.CENTER);
        getContentPane().add(backgroundPanel);
    }

    /**
     * Configures the properties of the main frame.
     */
    private void configureWindow() {
        setTitle("MacacoClicker");
        setSize(1000,750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * Changes the current view displayed in the main frame.
     * @param index The index of the view to switch to.
     */
    public void changeView(String index) {
        principalCardLayout.show(principalBorderLayout, index);
    }


    /**
     * Makes the main frame visible.
     */
    public void startView(){setVisible(true);}
}
