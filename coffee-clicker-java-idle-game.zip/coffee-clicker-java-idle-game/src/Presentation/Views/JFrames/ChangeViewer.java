package Presentation.Views.JFrames;

import Presentation.Views.BeginningPanel;
import Presentation.Views.LoginView;
import Presentation.Views.SignUpView;
import Presentation.Views.Tools.ImagePanel;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import Presentation.Views.Tools.Constants;

/**
 * JFrame that opens when we run the project.
 */
public class ChangeViewer extends JFrame {

    private final BeginningPanel beginningPanel;
    private final SignUpView signUpView;
    private final LoginView loginView;
    private final CardLayout principalCardLayout;
    private final JPanel principalBorderLayout;

    /**
     * Constructor that initializes the attributes of this JFrame.
     *
     * @param beginningPanel The first JPanel that appears when we run the project.
     * @param loginView JPanel that manages the log in of the users.
     * @param signUpView JPanel that manages the sign-up of the users.
     */
    public ChangeViewer(BeginningPanel beginningPanel, LoginView loginView, SignUpView signUpView) {
        this.beginningPanel = beginningPanel;
        this.loginView = loginView;
        this.signUpView = signUpView;
        principalCardLayout = new CardLayout();
        principalBorderLayout = new JPanel(principalCardLayout);
        configureWindow();
        configureView();
    }

    /**
     * Configuration of this JFrame.
     */
    private void configureView() {

        ImagePanel backgroundPanel = new ImagePanel("files/Images/Macacos.jpg");
        backgroundPanel.setLayout(new BorderLayout());

        principalBorderLayout.add(beginningPanel, Constants.BEGIN_ACTION);
        principalBorderLayout.add(loginView, Constants.LOGIN_ACTION);
        principalBorderLayout.add(signUpView, Constants.SIGN_UP_ACTION);

        JPanel infoCentral = new JPanel(new BorderLayout());
        infoCentral.setOpaque(false);

        infoCentral.add(principalBorderLayout, BorderLayout.CENTER);
        infoCentral.setBorder(new EmptyBorder(80,30,40,30));
        backgroundPanel.add(infoCentral, BorderLayout.CENTER);

        getContentPane().add(backgroundPanel);
    }

    /**
     * Changes the view inside the CardLayout.
     *
     * @param index The view to change to, identified by a string index.
     */
    public void changeView(String index) {
        principalCardLayout.show(principalBorderLayout, index);
    }

    /**
     * Configures the main settings of the JFrame.
     */
    private void configureWindow() {
        setTitle("MacacoClicker");
        setSize(800, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * Makes the JFrame visible.
     */
    public void startView() {
        setVisible(true);
    }

}