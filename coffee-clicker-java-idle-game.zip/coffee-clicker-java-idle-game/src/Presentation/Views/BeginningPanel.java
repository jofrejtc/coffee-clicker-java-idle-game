package Presentation.Views;

import Presentation.Views.Tools.ImagePanel;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import Presentation.Views.Tools.Constants;

/**
 * Class that displays the home screen.
 */
public class BeginningPanel extends JPanel {

    private final JButton loginButton;
    private final JButton registerButton;

    /**
     * Constructs the BeginningPanel.
     */
    public BeginningPanel() {

        setLayout(new BorderLayout());
        setBackground(new Color(56, 32, 18));

        JPanel principalPanel = new JPanel();
        principalPanel.setLayout(new FlowLayout());

        JPanel imagePanel = new JPanel();
        imagePanel.setBackground(Constants.MARRO_FONDO);

        JLabel titleLabel = new JLabel("MACACO CLICKER!");
        titleLabel.setForeground(Constants.ORANGE_COLOR);
        titleLabel.setBackground(Constants.MARRO_FONDO);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 60));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        principalPanel.setBackground(Constants.MARRO_FONDO);
        principalPanel.setLayout(new BoxLayout(principalPanel, BoxLayout.Y_AXIS));
        principalPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        principalPanel.add(titleLabel, BorderLayout.CENTER);
        principalPanel.add(imagePanel);

        add(principalPanel, BorderLayout.NORTH);

        ImageIcon icon = new ImageIcon("files/Images/MacacoButton.jpg");
        JLabel imageLabel = new JLabel(icon);
        imagePanel.add(imageLabel);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 0));
        buttonPanel.setBackground(new Color(56, 32, 18));
        registerButton = new JButton("SIGN UP");
        loginButton = new JButton("LOGIN");
        registerButton.setPreferredSize(new Dimension(200, 60));
        loginButton.setPreferredSize(new Dimension(200, 60));
        registerButton.setBackground(Constants.BUTTON_COLOR);
        loginButton.setBackground(Constants.BUTTON_COLOR);
        registerButton.setForeground(Constants.MARRO_FONDO);
        loginButton.setForeground(Constants.MARRO_FONDO);
        registerButton.setForeground(Color.BLACK);
        loginButton.setForeground(Color.BLACK);
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        buttonPanel.setBorder(new EmptyBorder(10, 0, 0, 0));
        add(buttonPanel);

    }

    /**
     * Adds ActionListener to the buttons.
     *
     * @param actionListener The ActionListener to be added to the buttons.
     */
    public void actionPerform(ActionListener actionListener) {
        loginButton.setActionCommand(Constants.LOGIN_ACTION);
        registerButton.setActionCommand(Constants.SIGN_UP_ACTION);
        loginButton.addActionListener(actionListener);
        registerButton.addActionListener(actionListener);
    }
}

