package Presentation.Views;

import Presentation.Views.Tools.Constants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * The StatsView class displays the graphic of the statistics.
 */
public class StatsView extends JPanel {

    private final JButton exitButton;

    /**
     * Constructs a new StatsView.
     */
    public StatsView() {

        setLayout(new BorderLayout());

        JPanel labelPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        labelPanel.setPreferredSize(new Dimension(100, 50));
        labelPanel.setBackground(Constants.MARRO_FONDO);
        JLabel label = new JLabel("GRAPHIC");
        Font font = new Font("Arial", Font.BOLD, 24);
        label.setFont(font);
        label.setForeground(Constants.ORANGE_COLOR);
        labelPanel.add(label);
        add(labelPanel, BorderLayout.NORTH);

        JPanel chartPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                int chartWidth = getWidth() - 100;
                int chartHeight = getHeight() - 100;

                g.setColor(Constants.BUTTON_COLOR);
                g.drawLine(50, chartHeight + 50, chartWidth + 50, chartHeight + 50);
                g.drawLine(50, 50, 50, chartHeight + 50);

                g.drawString("Time (min)", chartWidth / 2 + 50, chartHeight + 90);

                g.drawString("Number of Macacos", 20, chartHeight - 380);

                String[] labelsX = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
                for (int i = 0; i < labelsX.length; i++) {
                    int x = 80 + (i + 1) * chartWidth / (labelsX.length + 1);
                    g.drawString(labelsX[i], x, chartHeight + 70);
                }

                int[] labelsY = {0, 50, 100, 150, 200, 250, 300, 350, 400, 450};
                for (int i = 0; i < labelsY.length; i++) {
                    int y = chartHeight + 85 - (i + 1) * chartHeight / (labelsY.length + 1);
                    g.drawString(String.valueOf(labelsY[i]), 20, y);
                }

                int[] data = {60, 120, 180, 350, 380, 220, 290, 420, 350, 432};
                g.setColor(Color.ORANGE);
                int x = 50;
                int y = chartHeight + 50 -  (data[0]);
                for (int i = 0; i < data.length - 1; i++) {
                    int x2 = x + chartWidth / (data.length - 1);
                    int y2 = chartHeight + 50 -  (data[i + 1]);
                    g.fillOval(x - 4, y - 4, 8, 8);
                    g.drawLine(x, y, x2, y2);
                    x = x2;
                    y = y2;
                }
                g.fillOval(x - 4, y - 4, 8, 8);
            }
        };
        chartPanel.setBackground(Constants.MARRO_FONDO);
        add(chartPanel, BorderLayout.CENTER);

        exitButton = new JButton("Exit");
        exitButton.setFont(new Font("Arial", Font.BOLD, 12));
        exitButton.setBackground(Constants.BUTTON_COLOR);
        exitButton.setForeground(Constants.MARRO_FONDO);
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 30, 0));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        buttonPanel.setBackground(Constants.MARRO_FONDO);
        buttonPanel.add(exitButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Sets the ActionListener for the exit button.
     * @param actionListener The ActionListener to be set.
     */
    public void actionPerform(ActionListener actionListener) {
        exitButton.setActionCommand(Constants.START_ACTION);
        exitButton.addActionListener(actionListener);
    }
}