package Presentation.Views;

import Presentation.Views.Tools.Constants;
import Presentation.Views.Tools.TableBorderLayout;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Class that shows the different tables of shops.
 */
public class PrincipalRightContainer extends JPanel {

    private final JButton toolsButton;
    private final JButton upgradeButton;
    private final JButton currentGameButton;

    /**
     * Constructs the PrincipalRightContainer.
     *
     * @param tableBorderLayout The layout for the table.
     */
    public PrincipalRightContainer(TableBorderLayout tableBorderLayout) {
        setLayout(new BorderLayout());
        JPanel northPanel = new JPanel();

        toolsButton = new JButton("TOOLS SHOP");
        toolsButton.setBackground(Constants.BUTTON_COLOR);
        toolsButton.setForeground(Constants.MARRO_FONDO);
        toolsButton.setFont(new Font("Arial", Font.BOLD, 10));
        toolsButton.setPreferredSize(new Dimension(150, 40));

        upgradeButton = new JButton("UPGRADE SHOP");
        upgradeButton.setBackground(Constants.BUTTON_COLOR);
        upgradeButton.setForeground(Constants.MARRO_FONDO);
        upgradeButton.setFont(new Font("Arial", Font.BOLD, 10));
        upgradeButton.setPreferredSize(new Dimension(150, 40));

        currentGameButton = new JButton("CURRENT GAMES");
        currentGameButton.setBackground(Constants.BUTTON_COLOR);
        currentGameButton.setForeground(Constants.MARRO_FONDO);
        currentGameButton.setFont(new Font("Arial", Font.BOLD, 10));
        currentGameButton.setPreferredSize(new Dimension(150, 40));

        northPanel.setLayout(new BoxLayout(northPanel, BoxLayout.X_AXIS));
        northPanel.setBackground(Constants.MARRO_FONDO);
        northPanel.add(Box.createHorizontalGlue());
        northPanel.add(Box.createHorizontalStrut(10));
        northPanel.add(toolsButton);
        northPanel.add(Box.createHorizontalStrut(10));
        northPanel.add(upgradeButton);
        northPanel.add(Box.createHorizontalStrut(10));
        northPanel.add(currentGameButton);
        northPanel.add(Box.createHorizontalStrut(10));
        northPanel.add(Box.createHorizontalGlue());

        JPanel infoCentral = new JPanel(new BorderLayout());
        infoCentral.setOpaque(false);

        add(northPanel, BorderLayout.NORTH);

        infoCentral.add(tableBorderLayout.getPrincipalBorderLayout(), BorderLayout.CENTER);
        add(infoCentral, BorderLayout.CENTER);
    }

    /**
     * Displays a pop-up message.
     *
     * @param message The message to be displayed in the pop-up.
     */
    public void showPopUp(String message) {
        JOptionPane.showMessageDialog(null, message);
    }

    /**
     * Adds ActionListener to the buttons.
     *
     * @param listener The ActionListener to be added.
     */
    public void actionPerform(ActionListener listener) {
        toolsButton.setActionCommand(Constants.SHOP_ACTION);
        upgradeButton.setActionCommand(Constants.UPGRADE_ACTION);
        currentGameButton.setActionCommand(Constants.CURRENT_ACTION);
        toolsButton.addActionListener(listener);
        upgradeButton.addActionListener(listener);
        currentGameButton.addActionListener(listener);
    }
}

