package Presentation.Views;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import Presentation.Views.Tools.Constants;

/**
 * The SignUpView class represents the view for signing up.
 */
public class SignUpView extends JPanel {

    private final JButton signInPassButton;
    private final JButton backButton;
    private final JTextField userTextField;
    private final JTextField mailTextField;
    private final JPasswordField passwordTextField;
    private final JPasswordField confirmPasswordTextField;

    /**
     * Constructs a new SignUpView.
     */
    public SignUpView() {

        setBackground(Constants.MARRO_FONDO);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(new EmptyBorder(120, 20, 20, 20));

        // User
        JLabel userLabel = new JLabel("User:");
        userLabel.setForeground(Constants.ORANGE_COLOR);
        userLabel.setFont(new Font("Arial", Font.BOLD, 16));
        userLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(userLabel);

        userTextField = new JTextField();
        userTextField.setMaximumSize(new Dimension(300, 30));
        userTextField.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(userTextField);

        add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel mailLabel = new JLabel("Email:");
        mailLabel.setForeground(Constants.ORANGE_COLOR);
        mailLabel.setFont(new Font("Arial", Font.BOLD, 16));
        mailLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(mailLabel);

        mailTextField = new JTextField();
        mailTextField.setMaximumSize(new Dimension(300, 30));
        mailTextField.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(mailTextField);

        add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Constants.ORANGE_COLOR);
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 16));
        passwordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(passwordLabel);

        passwordTextField = new JPasswordField();
        passwordTextField.setMaximumSize(new Dimension(300, 30));
        passwordTextField.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(passwordTextField);

        add(Box.createRigidArea(new Dimension(0, 20)));

        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setForeground(Constants.ORANGE_COLOR);
        confirmPasswordLabel.setFont(new Font("Arial", Font.BOLD, 16));
        confirmPasswordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(confirmPasswordLabel);

        confirmPasswordTextField = new JPasswordField();
        confirmPasswordTextField.setMaximumSize(new Dimension(300, 30));
        confirmPasswordTextField.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(confirmPasswordTextField);

        add(Box.createRigidArea(new Dimension(0, 20)));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 0));
        buttonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        signInPassButton = new JButton("SIGN UP");
        signInPassButton.setBackground(Constants.ORANGE_COLOR);
        signInPassButton.setForeground(Color.BLACK);
        signInPassButton.setFont(new Font("Arial", Font.BOLD, 16));
        signInPassButton.setPreferredSize(new Dimension(150, 50));
        buttonPanel.add(signInPassButton);

        backButton = new JButton("BACK");
        backButton.setBackground(Constants.BROWN_COLOR);
        backButton.setForeground(Color.BLACK);
        backButton.setFont(new Font("Arial", Font.BOLD, 16));
        backButton.setPreferredSize(new Dimension(150, 50));
        buttonPanel.add(backButton);
        buttonPanel.setBackground(Constants.MARRO_FONDO);

        add(buttonPanel);

    }

    /**
     * method to clear the fields of the view
     */
    public void clearFields() {
        userTextField.setText("");
        mailTextField.setText("");
        passwordTextField.setText("");
        confirmPasswordTextField.setText("");
    }

    /**
     * Adds an ActionListener to the buttons of SignUpView.
     * @param actionListener The ActionListener to be added.
     */
    public void actionPerform(ActionListener actionListener) {
        backButton.setActionCommand(Constants.BEGIN_ACTION);
        signInPassButton.setActionCommand(Constants.INTERMEDIATE_ACTION);
        backButton.addActionListener(actionListener);
        signInPassButton.addActionListener(actionListener);
    }

    /**
     * Retrieves the entered user.
     *
     * @return The entered user.
     */
    public String getUser() {
        return userTextField.getText();
    }

    /**
     * Retrieves the entered email.
     *
     * @return The entered email.
     */
    public String getMail() {
        return mailTextField.getText();
    }

    /**
     * Retrieves the entered password.
     *
     * @return The entered password.
     */
    public String getPassword() {
        return passwordTextField.getText();
    }

    /**
     * Retrieves the entered confirm password.
     *
     * @return The entered confirm password.
     */
    public String getConfirmPassword() {
        return confirmPasswordTextField.getText();
    }

    /**
     * Displays a pop-up message.
     *
     * @param message The message to be displayed.
     */
    public void showPopUp(String message) {
        JOptionPane.showMessageDialog(null, message);
    }
}
