package Presentation.Views;

import Presentation.Views.Tools.Constants;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * The UpgradeView class displays the upgrade shop.
 */
public class UpgradeView extends JPanel {

    /**
     * Constructs a new UpgradeView.
     */
    public UpgradeView() {
        setBackground(Constants.MARRO_FONDO);
        DefaultTableModel tableModel;
        tableModel = new DefaultTableModel(
                new Object[][]{
                        {"Upgrade 1", "X2", 30, 200, 1000},
                        {"Upgrade 2", "X3", 60, 400, 2000},
                        {"Upgrade 3", "X4", 100, 800, 5000},
                        {"Upgrade 4", "X5", 200, 1000, 10000}},
                new String[]{"BUY Upgrade", "X BOOST", "Generator A", "Generator B", "Generator C"}
        ){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(tableModel);
        table.setAutoCreateRowSorter(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(200, 200));

        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(20, 20, 20, 20));
        add(scrollPane, BorderLayout.CENTER);
        setVisible(true);
    }

    /**
     * Retrieves the table from the JScrollPane viewport.
     * @return The table.
     */
    public JTable getTable() {
        JViewport viewport = (JViewport) ((JScrollPane) getComponent(0)).getComponent(0);
        return (JTable) viewport.getView();
    }

    /**
     * shows popUp
     * @param message message to throw
     */
    public void showPopUp(String message) {
        JOptionPane.showMessageDialog(null, message);
    }

}
