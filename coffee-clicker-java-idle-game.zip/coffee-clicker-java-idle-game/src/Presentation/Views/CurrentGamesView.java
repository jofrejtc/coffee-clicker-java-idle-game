package Presentation.Views;

import Presentation.Views.Tools.Constants;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

/**
 * Class that displays the table of the current games.
 */
public class CurrentGamesView extends JPanel {
    private final DefaultTableModel tableModel;

    /**
     * Constructs the CurrentGamesView.
     */
    public CurrentGamesView(){
        setBackground(Constants.MARRO_FONDO);

        tableModel = new DefaultTableModel(
                new Object[][]{},
                new String[]{"GameId", "Resource Counter", "Finished", "generators", "production"}
        );

        JTable table = new JTable(tableModel);
        table.setAutoCreateRowSorter(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(200, 200));

        setLayout(new BorderLayout());
        setBorder(new EmptyBorder(20,20,20,20));
        add(scrollPane, BorderLayout.CENTER);
        setVisible(true);
    }

    /**
     * Adds a row of data to the table.
     *
     * @param rowData The data to be added as a row to the table.
     */
    public void addRow(ArrayList<String> rowData) {
        Object[] rowArray = rowData.toArray();
        tableModel.addRow(rowArray);
    }

    /**
     * Gets the table component.
     *
     * @return The JTable component contained within the JScrollPane viewport.
     */
    public JTable getTable() {
        JViewport viewport = (JViewport) ((JScrollPane) getComponent(0)).getComponent(0);
        return (JTable) viewport.getView();
    }

    /**
     * Clears all rows from the table.
     */
    public void clearTable() {
        tableModel.setRowCount(0);
    }

    /**
     * Displays a popup message.
     *
     * @param message The message to be displayed.
     */
    public void showPopUp(String message) {
        JOptionPane.showMessageDialog(null, message);
    }

}
