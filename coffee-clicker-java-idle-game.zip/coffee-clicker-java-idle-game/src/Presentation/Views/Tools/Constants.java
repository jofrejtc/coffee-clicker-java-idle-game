package Presentation.Views.Tools;

import java.awt.*;
/**
 * The Constants class holds static final variables used throughout the application.
 * This includes action commands and common colors used in the UI.
 */
public class Constants {
    public static final String LOGIN_ACTION = "Login";
    public static final String BEGIN_ACTION = "Beginning";
    public static final String SIGN_UP_ACTION = "Register";
    public static final String INTERMEDIATE_ACTION = "Intermediate";
    public static final String START_ACTION = "Start";
    public static final String OPTIONS_ACTION = "Options";
    public static final String STATS_ACTION = "Stats";
    public static final String SHOP_ACTION = "Shop";
    public static final String FINISHED_ACTION = "Finished";
    public static final String UPGRADE_ACTION = "Upgrade";
    public static final String MACACO_ACTION = "Macaco";
    public static final String CURRENT_ACTION = "Current";
    public static final String DELETE_ACTION = "Delete";

    public static final Color ORANGE_COLOR = new Color(255, 165, 0);
    public static final Color BROWN_COLOR = new Color(139, 69, 19);
    public static final String FINISH_ACTUAL_ACTION = "Finish actual";
    public static final Color BUTTON_COLOR = new Color(155, 142, 107);
    public static final Color MARRO_FONDO = new Color(56, 32, 18);
}
