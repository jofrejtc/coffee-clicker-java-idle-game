package Presentation.Views.Tools;

import javax.swing.*;
import java.awt.*;

/**
 * Class that creates a panel with a background image.
 */
public class ImagePanel extends JPanel {
    private final Image backgroundImage;

    /**
     * Constructs an ImagePanel with the specified image path.
     *
     * @param imagePath The path to the background image.
     */
    public ImagePanel(String imagePath) {
        backgroundImage = new ImageIcon(imagePath).getImage();
    }


    /**
     * Paints the background image on the panel.
     *
     * @param g The Graphics object to protect.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
    }

    /**
     * Gets the preferred size of the panel based on the background image size.
     *
     * @return The preferred dimensions of the panel.
     */
    @Override
    public Dimension getPreferredSize() {
        return new Dimension(backgroundImage.getWidth(this), backgroundImage.getHeight(this));
    }
}