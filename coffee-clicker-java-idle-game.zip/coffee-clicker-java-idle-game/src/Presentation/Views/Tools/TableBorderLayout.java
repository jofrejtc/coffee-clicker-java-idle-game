package Presentation.Views.Tools;


import Presentation.Views.CurrentGamesView;
import Presentation.Views.ShopView;
import Presentation.Views.UpgradeView;

import javax.swing.*;
import java.awt.*;

/**
 * Class that manages a card layout with different views.
 */
public class TableBorderLayout extends JPanel {
    private final JPanel principalBorderLayout;
    private final CardLayout principalCardLayout;

    /**
     * Constructs the TableBorderLayout with the specified views.
     *
     * @param shopView The shop view to be added to the layout.
     * @param upgradeView The upgrade view to be added to the layout.
     * @param currentGamesView The current games view to be added to the layout.
     */
    public TableBorderLayout(ShopView shopView, UpgradeView upgradeView, CurrentGamesView currentGamesView) {
        principalCardLayout = new CardLayout();
        principalBorderLayout = new JPanel(principalCardLayout);

        principalBorderLayout.add(shopView, Constants.SHOP_ACTION);
        principalBorderLayout.add(upgradeView, Constants.UPGRADE_ACTION);
        principalBorderLayout.add(currentGamesView, Constants.CURRENT_ACTION);
    }

    /**
     * Gets the principal border layout panel.
     *
     * @return The JPanel containing the principal border layout.
     */
    public JPanel getPrincipalBorderLayout() {
        return principalBorderLayout;
    }

    /**
     * Gets the principal card layout.
     *
     * @return The CardLayout managing the principal border layout.
     */
    public CardLayout getPrincipalCardLayout(){
        return principalCardLayout;
    }
}
