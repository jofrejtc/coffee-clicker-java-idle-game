package Presentation.Views.Tools;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Class that creates a button with an image that changes when pressed.
 */
public class ImageButton extends JButton {
    private final Image image;
    private final Image pressedImage;

    /**
     * Constructs an ImageButton with the specified image path.
     *
     * @param imagePath The path to the image.
     */
    public ImageButton(String imagePath) {
        ImageIcon icon = new ImageIcon(imagePath);
        image = icon.getImage();

        pressedImage = createPressedImage(image);

        setPreferredSize(new Dimension(image.getWidth(this), image.getHeight(this)));

        setBorderPainted(false);
        setFocusPainted(false);
        setContentAreaFilled(false);

        getModel().addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if (getModel().isPressed()) {
                    setIcon(new ImageIcon(pressedImage));
                } else {
                    setIcon(new ImageIcon(image));
                }
            }
        });
    }

    /**
     * Creates an image that is displayed when the button is pressed.
     *
     * @param image The original image.
     * @return The modified image to be displayed when the button is pressed.
     */
    private Image createPressedImage(Image image) {
        BufferedImage pressedImg = new BufferedImage(image.getWidth(this), image.getHeight(this), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = pressedImg.createGraphics();
        g2.drawImage(image, 0, 0, this);
        g2.setColor(new Color(0, 0, 0, 100));
        g2.fillRect(0, 0, pressedImg.getWidth(), pressedImg.getHeight());
        g2.dispose();
        return pressedImg;
    }
}