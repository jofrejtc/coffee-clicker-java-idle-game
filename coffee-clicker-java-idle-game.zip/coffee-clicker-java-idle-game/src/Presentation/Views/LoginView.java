package Presentation.Views;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.*;
import java.awt.event.ActionListener;
import Presentation.Views.Tools.Constants;

/**
 * Class that shows the Login option.
 */
public class LoginView extends JPanel {

    private final JButton logPassButton;
    private final JButton backButton;
    private final JTextField username;
    private final JPasswordField password;
    private String originalPassword;

    /**
     * Constructs the LoginView.
     */
    public LoginView() {

        originalPassword = "";
        setBackground(Constants.MARRO_FONDO);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(new EmptyBorder(170, 20, 20, 20));

        JLabel userLabel = new JLabel("Username or Email:");
        userLabel.setForeground(Constants.ORANGE_COLOR);
        userLabel.setFont(new Font("Arial", Font.BOLD, 16));
        userLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(userLabel);

        username = new JTextField();
        username.setMaximumSize(new Dimension(300, 30));
        username.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(username);

        add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Constants.ORANGE_COLOR);
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 16));
        passwordLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(passwordLabel);

        password = new JPasswordField();
        password.setMaximumSize(new Dimension(300, 30));
        password.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(password);

        ((AbstractDocument) password.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                super.replace(fb, offset, length, text.replaceAll("\\.", "*"), attrs);
                updateOriginalPassword(offset, length, text);
            }
        });

        add(Box.createRigidArea(new Dimension(0, 20)));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 0));
        buttonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        logPassButton = new JButton("LOG IN");
        logPassButton.setBackground(Constants.ORANGE_COLOR);
        logPassButton.setForeground(Color.BLACK);
        logPassButton.setFont(new Font("Arial", Font.BOLD, 16));
        logPassButton.setPreferredSize(new Dimension(150, 50));
        buttonPanel.add(logPassButton);

        backButton = new JButton("BACK");
        backButton.setBackground(Constants.BROWN_COLOR);
        backButton.setForeground(Color.BLACK);
        backButton.setFont(new Font("Arial", Font.BOLD, 16));
        backButton.setPreferredSize(new Dimension(150, 50));
        buttonPanel.add(backButton);
        buttonPanel.setBackground(Constants.MARRO_FONDO);

        add(buttonPanel);
    }

    /**
     * Adds ActionListener to the buttons.
     *
     * @param actionListener The ActionListener to be added to the buttons.
     */
    public void actionPerform(ActionListener actionListener) {
        backButton.setActionCommand(Constants.BEGIN_ACTION);
        logPassButton.setActionCommand(Constants.INTERMEDIATE_ACTION);
        backButton.addActionListener(actionListener);
        logPassButton.addActionListener(actionListener);
    }

    /**
     * Method that gets the username data.
     *
     * @return The username data.
     */
    public String getUsernameData() {
        return username.getText();
    }

    /**
     * Updates the original password.
     *
     * @param offset The offset at which to start replacing.
     * @param length The length of the text to replace.
     * @param text The new text to replace the old text.
     */
    private void updateOriginalPassword(int offset, int length, String text) {
        StringBuilder builder = new StringBuilder(originalPassword);
        builder.delete(offset, offset + length);
        builder.insert(offset, text);
        originalPassword = builder.toString();
    }

    /**
     * Method that gets the password data.
     *
     * @return The password data.
     */
    public String getPasswordData() {
        return originalPassword;
    }

    /**
     * Clears the fields.
     */
    public void clearFields() {
        username.setText("");
        password.setText("");
        originalPassword = "";
    }

    /**
     * Displays a popup message.
     *
     * @param message The message to be displayed.
     */
    public void showPopUp(String message) {
        JOptionPane.showMessageDialog(null, message);
    }
}
