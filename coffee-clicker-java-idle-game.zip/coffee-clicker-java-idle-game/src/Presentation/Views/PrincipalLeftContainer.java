package Presentation.Views;

import Presentation.Views.Tools.Constants;
import Presentation.Views.Tools.ImageButton;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Class that shows the button of the counter and a table with the generators.
 */
public class PrincipalLeftContainer extends JPanel  {
    private final ImageButton macacoButton;
    private int macacoNumber;
    private final JLabel macacoCounter;
    private final JTable infoActual;
    private final DefaultTableModel tableModel;

    /**
     * Constructs the PrincipalLeftContainer.
     */
    public PrincipalLeftContainer() {
        macacoButton = new ImageButton("files/Images/MacacoButton.jpg");
        macacoNumber = 0;
        setBackground(Constants.MARRO_FONDO);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        macacoButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createVerticalStrut(30));

        JPanel panelAux = new JPanel();
        panelAux.setBackground(Constants.MARRO_FONDO);

        macacoCounter = new JLabel("MACACOS: " + macacoNumber);
        macacoCounter.setForeground(Constants.ORANGE_COLOR);
        macacoCounter.setFont(new Font("Arial", Font.BOLD, 16));
        macacoCounter.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelAux.add(macacoCounter);

        String[] column = {"Name", "Quantity", "Unit Production", "Total Production", "%Global Production"};
        tableModel = new DefaultTableModel(column, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };


        infoActual = new JTable(tableModel);

        infoActual.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = infoActual.rowAtPoint(e.getPoint());
            }
        });

        JScrollPane scrollPane = new JScrollPane(infoActual);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(200, 200));

        JPanel panelAux2 = new JPanel(new BorderLayout());
        panelAux2.add(scrollPane, BorderLayout.CENTER);

        add(macacoButton);
        add(Box.createVerticalStrut(15));
        add(panelAux);
        add(Box.createVerticalStrut(15));
        add(panelAux2);
        setBackground(Constants.MARRO_FONDO);

        setVisible(true);
    }

    /**
     * Adds ActionListener to the macaco button.
     *
     * @param listener The ActionListener to be added.
     */
    public void actionPerform(ActionListener listener) {
        macacoButton.setActionCommand(Constants.MACACO_ACTION);
        macacoButton.addActionListener(listener);
    }

    /**
     * Sets the number of macacos and updates the label.
     *
     * @param macacoNumber The number of macacos.
     */
    public void setMacacoNumber(float macacoNumber) {
        this.macacoNumber = (int) macacoNumber;

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                macacoCounter.setText("MACACOS: " + (int) macacoNumber);
            }
        });

    }

    /**
     * Adds a new row to the table.
     *
     * @param rowData The data for the new row.
     */
    public void addRow(Object[] rowData) {
        tableModel.addRow(rowData);
    }

    /**
     * Clears all rows in the table.
     */
    public void clearTable() {
        tableModel.setRowCount(0);
    }

    /**
     * Method that displays a popup message.
     *
     * @param message The message to be displayed.
     */
    public void showPopUp(String message) {
        JOptionPane.showMessageDialog(null, message);
    }

}
