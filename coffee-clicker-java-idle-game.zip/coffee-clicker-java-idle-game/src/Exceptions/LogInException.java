package Exceptions;

import java.io.IOException;

/**
 * Exception thrown when an error occurs during the login process.
 */
public class LogInException extends IOException {

    /**
     * Constructs a new LogInException with the specified detail message.
     *
     * @param message The detail message.
     */
    public LogInException(String message) {
        super(message);
    }
}
