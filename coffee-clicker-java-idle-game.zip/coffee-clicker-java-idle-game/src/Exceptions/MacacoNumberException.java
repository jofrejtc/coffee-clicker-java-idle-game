package Exceptions;

/**
 * This is the main exception class for Macaco number-related issues.
 * All other exceptions related to Macaco numbers will extend from this one.
 */
public class MacacoNumberException extends NullPointerException {

    /**
     * Constructs a new MacacoNumberException with the specified detail message.
     *
     * @param message The detail message.
     */
    public MacacoNumberException(String message) {
        super(message);
    }
}
