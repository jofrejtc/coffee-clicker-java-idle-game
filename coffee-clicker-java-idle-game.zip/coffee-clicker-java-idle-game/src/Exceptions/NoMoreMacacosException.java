package Exceptions;

/**
 * Exception thrown when there are no more macacos available.
 */
public class NoMoreMacacosException extends Exception {

    /**
     * Constructs a new NoMoreMacacosException with the specified detail message.
     *
     * @param message The detail message.
     */
    public NoMoreMacacosException(String message) {
        super(message);
    }
}
