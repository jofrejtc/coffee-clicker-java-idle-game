package Exceptions;

import java.io.IOException;

/**
 * Exception thrown when an error occurs during the logout process.
 */
public class LogOutException extends IOException {

    /**
     * Constructs a new LogOutException with the specified detail message.
     *
     * @param message The detail message.
     */
    public LogOutException(String message) {
        super(message);
    }
}
