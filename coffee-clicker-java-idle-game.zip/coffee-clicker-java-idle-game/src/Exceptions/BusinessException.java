package Exceptions;

import java.io.IOException;

/**
 * Is the main exception, all the other exceptions will extend from this one
 */
public class BusinessException extends IOException {
    /**
     * A constructor for the BusinessException
     * @param message is the message the exception will throw
     */
    public BusinessException(String message) {
        super(message);
    }
}
