package Exceptions;

import java.io.IOException;

/**
 * Exception thrown when an error occurs related to JSON processing.
 */
public class JSONErrorException extends IOException {

    /**
     * Constructs a new JSONErrorException with the specified detail message.
     *
     * @param message The detail message.
     */
    public JSONErrorException(String message) {
        super(message);
    }
}
