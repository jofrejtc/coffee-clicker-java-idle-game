package Exceptions;

/**
 * Exception thrown when an error occurs during the sign-up process.
 */
public class SignUpException extends Exception {

    /**
     * Constructs a new SignUpException with the specified detail message.
     *
     * @param message The detail message.
     */
    public SignUpException(String message) {
        super(message);
    }
}
