package Exceptions;

import java.sql.SQLException;

/**
 * Exception thrown when an error occurs during persistence operations.
 */
public class PersistenceException extends SQLException {

    /**
     * Constructs a new PersistenceException with the specified detail message.
     *
     * @param message The detail message.
     */
    public PersistenceException(String message) {
        super(message);
    }
}
