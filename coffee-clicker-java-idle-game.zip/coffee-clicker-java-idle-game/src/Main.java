import Business.Entities.Config;
import Business.Managers.GameManager;
import Business.Managers.UpgradeManager;
import Business.Managers.UserManager;
import Exceptions.PersistenceException;
import Persistence.ReadConfigDAO;
import Persistence.sql.GameSQL;
import Persistence.sql.SQLConnector;
import Presentation.Views.Tools.TableBorderLayout;
import Persistence.json.ReadConfigJSON;
import Persistence.sql.UserSQL;
import Presentation.Controllers.*;
import Presentation.Views.*;
import Presentation.Views.JFrames.ChangeViewer;
import Presentation.Views.JFrames.PrincipalViewer;


/**
 * The Main class initializes and runs the application, setting up all necessary views, controllers,
 * and managers, and handling the configuration and connection to the database.
 */
public class Main {
    /**
     * The main method of the application.
     * @param args command-line arguments
     */
    public static void main(String[] args) {

        BeginningPanel beginningPanel = new BeginningPanel();
        LoginView loginView = new LoginView();
        SignUpView signUpView = new SignUpView();

        OptionsView optionsView = new OptionsView();
        StatsView statsView = new StatsView();
        FinishedGamesView finishedGamesView = new FinishedGamesView();
        UpgradeView upgradeView = new UpgradeView();
        CurrentGamesView currentGamesView = new CurrentGamesView();
        ShopView shopView = new ShopView();
        IntermediatePanel intermediatePanel = new IntermediatePanel();

        TableBorderLayout tableBorderLayout = new TableBorderLayout(shopView, upgradeView, currentGamesView);
        PrincipalRightContainer principalRightContainer = new PrincipalRightContainer(tableBorderLayout);

        ReadConfigDAO config2 = new ReadConfigJSON();
        Config config= config2.loadConfiguration();
        SQLConnector sqlConnector;
        try {
            sqlConnector = SQLConnector.getInstance(config);
            sqlConnector.connect();
        } catch (PersistenceException e) {
            throw new RuntimeException(e);
        }
        UserSQL userSQL = new UserSQL(sqlConnector);
        GameSQL gameSQL = new GameSQL(sqlConnector);

        GameManager gameManager = new GameManager(gameSQL);

        PrincipalLeftContainer principalLeftContainer = new PrincipalLeftContainer();//Aqui pasarem per parametre el contador de micos i el numero de generadors comprats(tambe pasarem les caracteristiques mes endevant)
        StartGameView startGameView = new StartGameView(tableBorderLayout, principalRightContainer, principalLeftContainer);

        ChangeViewer changeViewer = new ChangeViewer(beginningPanel, loginView, signUpView);
        PrincipalViewer principalViewer = new PrincipalViewer(startGameView, optionsView, statsView, finishedGamesView, intermediatePanel);


        UserManager userManager = new UserManager(userSQL);
        UpgradeManager upgradeManager = new UpgradeManager();

        LeftContainerController leftContainerController = new LeftContainerController(principalLeftContainer, gameManager);
        IntermediatePanelController intermediatePanelController = new IntermediatePanelController(changeViewer, principalViewer, leftContainerController,intermediatePanel, gameManager, userManager);
        new BeginningController(changeViewer, beginningPanel);
        new LoginController(changeViewer, principalViewer, loginView, userManager, intermediatePanelController);
        new SignUpController(changeViewer, principalViewer, signUpView, userManager, intermediatePanelController);
        new StatsViewController(principalViewer, statsView);

        new ShopViewController(shopView, gameManager, leftContainerController);
        new UpgradeViewController(upgradeView,gameManager,upgradeManager, leftContainerController);
        CurrentGamesViewController currentGamesViewController = new CurrentGamesViewController(principalViewer, currentGamesView, gameManager, userManager);

        new RightContainerController(startGameView, principalRightContainer, currentGamesViewController, gameManager);
        new OptionsController(principalViewer, optionsView, userManager,gameManager, changeViewer, intermediatePanelController, leftContainerController);
        FinishedGamesController finishedGamesController = new FinishedGamesController(principalViewer, finishedGamesView, gameManager, userManager, leftContainerController, intermediatePanelController);
        new StartGameController(principalViewer, startGameView, finishedGamesController);
    }
}