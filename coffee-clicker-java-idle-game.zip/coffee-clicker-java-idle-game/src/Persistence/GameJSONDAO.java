package Persistence;

import Business.Entities.Game;
import Exceptions.PersistenceException;

import java.util.ArrayList;
import java.util.List;
/**
 * GameJSONDAO interface provides methods to interact with JSON files for game-related operations.
 */
public interface GameJSONDAO {
    /**
     * Checks if a file with the specified name exists.
     *
     * @param fileName The name of the file to check.
     * @return true if the file exists, false otherwise.
     */
    boolean doesFileExist(String fileName);

    /**
     * Saves a game to a JSON file.
     *
     * @param game The game to save.
     * @return The path to the saved JSON file.
     * @throws PersistenceException if there is an error during the operation.
     */
    String saveGame(Game game) throws PersistenceException;

    /**
     * Loads a game from a JSON file.
     *
     * @param gameId The ID of the game to load.
     * @return The loaded Game object.
     * @throws PersistenceException if there is an error during the operation.
     */
    Game loadGame(int gameId) throws PersistenceException;

    /**
     * Charges all games from the persistence storage.
     *
     * @return An ArrayList of Game objects.
     */
    ArrayList<Game> chargeAllGamesFromPersistence();

    /**
     * Saves all games to the persistence storage.
     *
     * @param games A list of Game objects to save.
     * @throws PersistenceException if there is an error during the operation.
     */
    void setAllGamesToPersistence(List<Game> games) throws PersistenceException;
}
