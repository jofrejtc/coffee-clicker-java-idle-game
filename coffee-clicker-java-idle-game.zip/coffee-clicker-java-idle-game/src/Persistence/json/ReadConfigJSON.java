package Persistence.json;

import Business.Entities.Config;
import Persistence.ReadConfigDAO;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
/**
 * Class that reads the database configuration from a JSON file.
 */
public class ReadConfigJSON implements ReadConfigDAO {

    /**
     * Default constructor.
     */
    public ReadConfigJSON() {

    }

    /**
     * Method that loads the configuration from the JSON file and returns a Config object.
     * @return Config loaded from the JSON file.
     */
    public Config loadConfiguration() {
        try {
            Gson gson = new Gson();
            Reader reader = Files.newBufferedReader(Paths.get("files/ConfigDB/config.json"));
            Config config = gson.fromJson(reader, Config.class);
            reader.close();
            return config;
        } catch (IOException e) {
            throw new RuntimeException("Error reading configuration file", e);
        }
    }
}