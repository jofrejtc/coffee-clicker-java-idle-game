package Persistence.json;

import Business.Entities.Game;
import Business.Entities.Generator;
import Exceptions.PersistenceException;
import Persistence.GameJSONDAO;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
/**
 * Implementation of the GameJSONDAO interface for JSON-based persistence of games.
 */
public class GameJSON implements GameJSONDAO {

    private static final Path JSON_DIRECTORY = Paths.get("files", "Games");
    private final Gson gson;

    /**
     * Registering the GeneratorDeserializer with Gson
     */
    public GameJSON() {
        this.gson = new GsonBuilder()
                .registerTypeAdapter(Generator.class, new GeneratorDeserializer())
                .setPrettyPrinting()
                .create();
    }

    /**
     * Checks if a file with the specified name exists.
     *
     * @param fileName The name of the file to check.
     * @return true if the file exists, false otherwise.
     */
    public boolean doesFileExist(String fileName) {
        Path jsonFilePath = JSON_DIRECTORY.resolve(fileName);
        return Files.exists(jsonFilePath);
    }

    /**
     * Saves a game to a JSON file named with the game's ID.
     *
     * @param game The game to save.
     * @return The path to the saved JSON file.
     * @throws PersistenceException if there is an error during the operation.
     */
    public String saveGame(Game game) throws PersistenceException {
        String fileName = "game_" + game.getId() + ".json";
        Path jsonFilePath = JSON_DIRECTORY.resolve(fileName);
        try{
            if (!Files.exists(JSON_DIRECTORY)) {
                Files.createDirectories(JSON_DIRECTORY);
            }
            String json = gson.toJson(game);
            Files.writeString(jsonFilePath, json);
        } catch (IOException e){
            throw new PersistenceException("Error amb el json de Game.");
        }
        return jsonFilePath.toString();
    }

    /**
     * Loads a game from a JSON file named with the game's ID.
     *
     * @param gameId The ID of the game to load.
     * @return The loaded Game object.
     * @throws PersistenceException if there is an error during the operation.
     */
    public Game loadGame(int gameId) throws PersistenceException {
        String fileName = "game_" + gameId + ".json";
        Path jsonFilePath = JSON_DIRECTORY.resolve(fileName);
        try {

            String json = Files.readString(jsonFilePath);

            return gson.fromJson(json, Game.class);
        } catch (IOException e) {
            throw new PersistenceException("Error amb el json de Game 2.");
        }
    }

    /**
     * Loads all games from the JSON persistence storage.
     *
     * @return An ArrayList of Game objects.
     */
    public ArrayList<Game> chargeAllGamesFromPersistence() {
        ArrayList<Game> games = new ArrayList<>();
        int compt = 0;
        boolean thereAreMoreGames = true;

        while (thereAreMoreGames) {
            try {
                Game game = loadGame(compt);
                games.add(game);
                compt++;
            } catch (PersistenceException e) {
                thereAreMoreGames = false;
            }
        }

        return games;
    }

    /**
     * Saves all games to the JSON persistence storage.
     *
     * @param games A list of Game objects to save.
     * @throws PersistenceException if there is an error during the operation.
     */
    public void setAllGamesToPersistence(List<Game> games) throws PersistenceException {
        try {
            if (!Files.exists(JSON_DIRECTORY)) {
                Files.createDirectories(JSON_DIRECTORY);
            }
            for (Game game : games) {
                String fileName = "game_" + game.getId() + ".json";
                Path jsonFilePath = JSON_DIRECTORY.resolve(fileName);
                String json = gson.toJson(game);
                Files.writeString(jsonFilePath, json);
            }
        } catch (IOException e) {
            throw new PersistenceException("Error al guardar los juegos en el sistema de archivos JSON.");
        }
    }
}