package Persistence.json;

import Business.Entities.Generator;
import Business.Entities.GeneratorA;
import Business.Entities.GeneratorB;
import Business.Entities.GeneratorC;
import com.google.gson.*;

import java.lang.reflect.Type;

/**
 * Logic to determine and instantiate the appropriate concrete class that implements Generator
 */
public class GeneratorDeserializer implements JsonDeserializer<Generator> {
    /**
     * Deserializes a JSON element into the appropriate Generator subclass based on the "type" field.
     *
     * @param json The JSON element to deserialize.
     * @param typeOfT The type of the object to deserialize.
     * @param context The context of the deserialization process.
     * @return The deserialized Generator object.
     * @throws JsonParseException if the JSON element cannot be deserialized into a Generator object.
     */
    @Override
    public Generator deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        JsonObject jsonObject = json.getAsJsonObject();
        if (jsonObject.has("type")) {
            String type = jsonObject.get("type").getAsString();
            return switch (type) {
                case "A" -> context.deserialize(jsonObject, GeneratorA.class);
                case "B" -> context.deserialize(jsonObject, GeneratorB.class);
                case "C" -> context.deserialize(jsonObject, GeneratorC.class);
                default -> throw new JsonParseException("Unknown generator type: " + type);
            };
        } else {
            throw new JsonParseException("Generator type field is missing");
        }
    }
}