package Persistence;

import Business.Entities.Config;

/**
 * Interface to define the operations for loading configuration details from a JSON file.
 */
public interface ReadConfigDAO {
    /**
     * loads the configuration settings for a JSON file.
     * @return the Config loaded.
     */
    Config loadConfiguration();
}