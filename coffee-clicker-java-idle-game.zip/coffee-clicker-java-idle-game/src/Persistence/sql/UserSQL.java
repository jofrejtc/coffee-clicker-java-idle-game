package Persistence.sql;

import Business.Entities.User;
import Exceptions.PersistenceException;
import Persistence.UserDAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of the UserDAO interface for SQL-based persistence.
 */
public class UserSQL implements UserDAO {
    private final SQLConnector sqlConnector;

    /**
     * Constructs a UserSQL object with the specified SQLConnector.
     *
     * @param sqlConnector The SQLConnector for database operations.
     */
    public UserSQL(SQLConnector sqlConnector) {
        this.sqlConnector=sqlConnector;
    }

    /**
     * Adds a null user to the database.
     *
     * @throws PersistenceException if there is an error during the operation.
     */
    public void addNullUser() throws PersistenceException {
        String query = "INSERT INTO `users`(`username`, `email`, `password`)   VALUES ('NULL ', 'NULL', 'NULL');";
        sqlConnector.insertQuery(query);

    }

    /**
     * Checks if the database is empty and adds the user if it is.
     *
     * @param user The user to add.
     * @return true if the user was successfully added, false otherwise.
     * @throws PersistenceException if there is an error during the operation.
     */
    @Override
    public boolean addUser(User user) throws PersistenceException {

        if (isDatabaseEmpty()) {
            try {
                addNullUser();
            } catch (PersistenceException e) {
                throw new PersistenceException("There was a problem adding a null user.");
            }
        }

        String query = "INSERT INTO `users`(`username`, `email`, `password`)   VALUES ('" +
                user.getUsername() + "', '" +
                user.getEmail() + "', '" +
                user.getPassword() +
                "');";
        sqlConnector.insertQuery(query);

        return true;
    }

    /**
     * Checks if the database is empty.
     *
     * @return true if the database is empty, false otherwise.
     * @throws PersistenceException if there is an error during the operation.
     */
    private boolean isDatabaseEmpty() throws PersistenceException {
        String query = "SELECT COUNT(*) AS count FROM users;";
        ResultSet resultSet = null;
        try {
            resultSet = sqlConnector.selectQuery(query);

            if (resultSet.next()) {
                int count = resultSet.getInt("count");
                return count == 0;
            }
        }
        catch (SQLException e) {
            throw new PersistenceException("There was a problem with the database.");
        }
        finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    throw new PersistenceException("There was a problem with the database.");
                }
            }
        }
        return false;
    }

    /**
     * Retrieves a user by their email.
     *
     * @param email The email of the user.
     * @return The User object if found, or null if not.
     * @throws PersistenceException if there is an error during the operation.
     */
    @Override
    public User getUserByEmail(String email) throws PersistenceException {
        User user = null;
        String query = "SELECT * FROM users WHERE email = '" + email + "';";
        ResultSet resultSet = sqlConnector.selectQuery(query);

        try {
            if (resultSet.next()) {
                user = new User(
                        resultSet.getString("username"),
                        resultSet.getString("email"),
                        resultSet.getString("password")
                );
            }
        } catch (SQLException e) {
            throw new PersistenceException("There was a problem with the database.");
        }

        return user;
    }

    /**
     * Retrieves a user by their username.
     *
     * @param username The username of the user.
     * @return The User object if found, or null if not.
     * @throws PersistenceException if there is an error during the operation.
     */
    @Override
    public User getUserByUsername(String username) throws PersistenceException {
        User user = null;
        String query = "SELECT * FROM users WHERE username = '" + username + "';";
        ResultSet resultSet = sqlConnector.selectQuery(query);

        try {
            if (resultSet.next()) {
                user = new User(
                        resultSet.getString("username"),
                        resultSet.getString("email"),
                        resultSet.getString("password")
                );
            }
        } catch (SQLException e) {
            throw new PersistenceException("There was a problem with the database.");
        }
        return user;
    }

    /**
     * Retrieves all users from the database.
     *
     * @return A list of User objects representing all users in the database.
     * @throws PersistenceException if there is an error accessing the database.
     */
    @Override
    public List<User> getAllUsers() throws PersistenceException {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM users;";
        ResultSet resultSet = sqlConnector.selectQuery(query);
        try {
            while (resultSet.next()) {
                User user = new User(
                        resultSet.getString("username"),
                        resultSet.getString("email"),
                        resultSet.getString("password")
                );
                users.add(user);
            }
        } catch (SQLException e) {
            throw new PersistenceException("There was a problem with the database.");
        }
        return users;
    }


    /**
     * Deletes a user from the database.
     *
     * @param user The user to delete.
     * @return true if the user was successfully deleted, false otherwise.
     * @throws PersistenceException if there is an error during the operation.
     */
    @Override
    public boolean deleteUser(User user) throws PersistenceException {
        String query = "DELETE FROM users WHERE username = '" + user.getUsername() + "';";
        try {
            sqlConnector.deleteQuery(query);
            return true;
        } catch (SQLException e) {
            throw new PersistenceException("There was a problem with the database.");
        }
    }


    /**
     * Tries to get the user by username first. If no user is found by username, tries email.
     *
     * @param credential The username or email of the user.
     * @return The User object if found, or null if not.
     * @throws PersistenceException if there is an error during the operation.
     */
    @Override
    public User getUserByUsernameOrEmail(String credential) throws PersistenceException {
        User user = getUserByUsername(credential);
        if (user == null) {
            user = getUserByEmail(credential);
        }
        return user;
    }

    /**
     * Retrieves the user ID by their email.
     *
     * @param email The email of the user.
     * @return The user ID if found.
     * @throws PersistenceException if there is an error during the operation.
     */
    public int getUserIdByEmail(String email) throws PersistenceException {
        String query = "SELECT user_id FROM users WHERE email = '" + email + "';";
        ResultSet resultSet = sqlConnector.selectQuery(query);

        try {
            if (resultSet.next()) {
                return resultSet.getInt("user_id");
            }
        } catch (SQLException e) {
            throw new PersistenceException("There was a problem with the database.");
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    throw new PersistenceException("There was a problem with the database.");
                }
            }
        }
        return -1;
    }
}