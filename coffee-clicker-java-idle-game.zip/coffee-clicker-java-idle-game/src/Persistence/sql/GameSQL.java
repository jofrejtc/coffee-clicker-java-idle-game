package Persistence.sql;

import Business.Entities.Game;
import Exceptions.PersistenceException;
import Persistence.GameSQLDAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of the GameSQLDAO interface for SQL-based persistence of game states.
 */
public class GameSQL implements GameSQLDAO {
    private final SQLConnector sqlConnector;

    /**
     * Constructs a GameSQL object with the specified SQLConnector.
     *
     * @param sqlConnector The SQLConnector for database operations.
     */
    public GameSQL(SQLConnector sqlConnector) {
        this.sqlConnector=sqlConnector;
    }

    /**
     * Adds a new game to the database.
     *
     * @param userId The ID of the user associated with the game.
     * @param gameId The ID of the game to add.
     * @return true if the game was successfully added, false otherwise.
     * @throws PersistenceException if there is an error during the operation.
     */
    public boolean addGame(int userId, int gameId) throws PersistenceException {
        String query = "INSERT INTO `game_states` (`user_id`, `game_id`) VALUES ('" +
                userId + "', " + gameId + ");";
        sqlConnector.insertQuery(query);
        return true;
    }

    /**
     * Updates the JSON path of a game in the database.
     *
     * @param gameId The ID of the game to update.
     * @param jsonPath The new JSON path to set.
     * @throws PersistenceException if there is an error during the operation.
     */
    public void updateGameJsonPath(int gameId, String jsonPath) throws PersistenceException {
        String query = "UPDATE game_states SET json_path = '" + jsonPath + "' WHERE game_id = " + gameId + ";";
        sqlConnector.updateQuery(query);

    }

    /**
     * Retrieves the ID of the last game added to the database.
     *
     * @return The ID of the last game.
     * @throws PersistenceException if there is an error during the operation.
     */
    public int getLastGameId() throws PersistenceException {
        String query = "SELECT MAX(game_id) AS last_id FROM game_states;";
        ResultSet resultSet = sqlConnector.selectQuery(query);
        try {
            if (resultSet.next()) {
                return resultSet.getInt("last_id");
            }
        } catch (SQLException e) {
            throw new PersistenceException("There was an error with the database");
        }
        return -1;
    }
    /**
     * Deletes all games associated with a specific user from the database.
     *
     * @param userId The ID of the user whose games are to be deleted.
     * @return true if the games were successfully deleted, false otherwise.
     * @throws PersistenceException if there is an error during the operation.
     */
    @Override
    public boolean deleteGamesByUser(int userId) throws PersistenceException {
        String query = "DELETE FROM game_states\n" +
                "WHERE user_id = (SELECT user_id FROM users WHERE user_id = '" + userId + "');";
        try {
            sqlConnector.deleteQuery(query);
            return true;
        } catch (SQLException e) {
            throw new PersistenceException("There was a problem with the database.");
        }
    }

    /**
     * Retrieves all games from the database.
     *
     * @return A list of Game objects.
     * @throws PersistenceException if there is an error during the operation.
     */
    @Override
    public List<Game> getAllGames() throws PersistenceException {
        List<Game> games = new ArrayList<>();
        String query = "SELECT * FROM game_states";
        ResultSet resultSet = sqlConnector.selectQuery(query);

        try{
            while (resultSet.next()){
                int gameId = resultSet.getInt("game_id");
                int userId = resultSet.getInt("user_id");

                Game game = new Game(userId, gameId);
                games.add(game);
            }
        } catch (SQLException e){
            throw new PersistenceException("Error getting information for games from the database.");
        }

        return games;
    }
}
