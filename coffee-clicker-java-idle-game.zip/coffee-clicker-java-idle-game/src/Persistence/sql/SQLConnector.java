package Persistence.sql;

import Business.Entities.Config;
import Exceptions.PersistenceException;

import java.sql.*;

/**
 * The SQLConnector class will abstract the specifics of the connection to a MySQL database.
 * This class follows the Singleton design pattern to facilitate outside access while maintaining
 * a single instance, as having multiple connectors to a database is generally discouraged.
 * Be aware that this class presents a simplified approach. Configuration parameters SHOULD NOT be
 * hardcoded and the use of Statements COULD be replaced by PreparedStatements to avoid SQL Injection.
 */
public class SQLConnector {
    private static SQLConnector instance = null;
    private final String username;
    private final String password;
    private final String url;
    private Connection conn;

    /**
     * Static method that returns the shared instance managed by the singleton.
     *
     * @param config Configuration object containing the database connection details.
     * @return The shared SQLConnector instance.
     * @throws PersistenceException if there is an error during the connection.
     */
    public static SQLConnector getInstance(Config config) throws PersistenceException {
        if (instance == null ){
            instance = new SQLConnector(config.getUsername(), config.getPassword(), config.getIp(), config.getPort(), config.getDatabase());
        }
        return instance;
    }
    private SQLConnector(String username, String password, String ip, int port, String database) {
        this.username = username;
        this.password = password;
        this.url = "jdbc:mysql://" + ip + ":" + port + "/" + database;
        //this.conn

    }

    /**
     * Method that starts the inner connection to the database. Ideally, users would disconnect after
     * using the shared instance.
     *
     * @throws PersistenceException if there is an error during the connection.
     */
    public void connect() throws PersistenceException {
        if (conn == null) {
            try {
                conn = DriverManager.getConnection(url, username, password);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }


    /**
     * Method that executes an insertion query to the connected database.
     *
     * @param query String representation of the query to execute.
     * @throws PersistenceException if there is an error during the operation.
     */
    public void insertQuery(String query) throws PersistenceException {
        try {
            Statement s = conn.createStatement();
            s.executeUpdate(query);
        } catch (SQLException e) {
            throw new PersistenceException("There was a problem with the database.");
        }
    }

    /**
     * Method that executes an update query to the connected database.
     *
     * @param query String representation of the query to execute.
     * @throws PersistenceException if there is an error during the operation.
     */
    public void updateQuery(String query) throws PersistenceException {
        try {
            Statement s = conn.createStatement();
            s.executeUpdate(query);
        } catch (SQLException e) {
            throw new PersistenceException("There was a problem with the database.");
        }
    }

    /**
     * Method that executes a deletion query to the connected database.
     *
     * @param query String representation of the query to execute.
     * @throws PersistenceException if there is an error during the operation.
     */
    public void deleteQuery(String query) throws PersistenceException {
        try {
            Statement s = conn.createStatement();
            s.executeUpdate(query);
        } catch (SQLException e) {
            throw new PersistenceException("There was a problem with the database a SQLConnector.");
        }
    }


    /**
     * Method that executes a selection query to the connected database.
     *
     * @param query String representation of the query to execute.
     * @return The results of the selection.
     * @throws PersistenceException if there is an error during the operation.
     */
    public ResultSet selectQuery(String query) throws PersistenceException {
        ResultSet rs;
        try {
            Statement s = conn.createStatement();
            rs = s.executeQuery(query);
            return rs;
        } catch (SQLException e) {
            throw new PersistenceException("There was a problem with the database.");
        }
    }
}