package Persistence;

import Business.Entities.Game;
import Exceptions.PersistenceException;

import java.util.List;
/**
 * GameSQLDAO interface provides methods to interact with the database for game-related operations.
 */
public interface GameSQLDAO {
    /**
     * Retrieves all games from the database.
     *
     * @return A list of Game objects.
     * @throws PersistenceException if there is an error during the operation.
     */
    List<Game> getAllGames() throws PersistenceException;

    /**
     * Adds a new game to the database.
     *
     * @param userId The ID of the user associated with the game.
     * @param gameId The ID of the game to add.
     * @return true if the game was successfully added, false otherwise.
     * @throws PersistenceException if there is an error during the operation.
     */
    boolean addGame(int userId, int gameId) throws PersistenceException;

    /**
     * Updates the JSON path of a game in the database.
     *
     * @param gameId The ID of the game to update.
     * @param jsonPath The new JSON path to set.
     * @throws PersistenceException if there is an error during the operation.
     */
    void updateGameJsonPath(int gameId, String jsonPath) throws PersistenceException;

    /**
     * Retrieves the ID of the last game added to the database.
     *
     * @return The ID of the last game.
     * @throws PersistenceException if there is an error during the operation.
     */
    int getLastGameId() throws PersistenceException;

    /**
     * Deletes all games associated with a specific user from the database.
     *
     * @param userId The ID of the user whose games are to be deleted.
     * @return true if the games were successfully deleted, false otherwise.
     * @throws PersistenceException if there is an error during the operation.
     */
    boolean deleteGamesByUser(int userId) throws PersistenceException;
}
