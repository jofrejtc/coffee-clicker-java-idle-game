package Persistence;
import Business.Entities.User;
import Exceptions.PersistenceException;

import java.util.List;
/**
 * UserDAO interface provides methods to interact with the database for user-related operations.
 */
public interface UserDAO {
    /**
     * Adds a new user to the database.
     * @param user The user to add.
     * @return true if the user was successfully added, false otherwise.
     */
    boolean addUser(User user) throws PersistenceException;

    /**
     * Retrieves a user by their email.
     * @param email The email of the user.
     * @return The User object if found, or null if not.
     */
    User getUserByEmail(String email) throws PersistenceException;

    /**
     * Retrieves a user by their username.
     * @param username The username of the user.
     * @return The User object if found, or null if not.
     */
    User getUserByUsername(String username) throws PersistenceException;

    /**
     * Retrieves all users from the database.
     * @return A List of User objects.
     */
    List<User> getAllUsers() throws PersistenceException;

    /**
     * Deletes a user from the database.
     * @param user The user to delete.
     * @return true if the user was successfully deleted, false otherwise.
     */
    boolean deleteUser(User user) throws PersistenceException;

    /**
     * Retrieves a user by their username or email.
     * @param credential the username or email of the user.
     * @return the User object if found, or null if not found.
     */
    User getUserByUsernameOrEmail(String credential) throws PersistenceException;

    /**
     * Retrieves the user ID by their email.
     *
     * @param email The email of the user.
     * @return The user ID if found.
     * @throws PersistenceException if there is an error during the operation.
     */
    int getUserIdByEmail(String email) throws PersistenceException;
}
