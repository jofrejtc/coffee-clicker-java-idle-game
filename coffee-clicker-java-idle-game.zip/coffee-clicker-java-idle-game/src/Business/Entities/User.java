package Business.Entities;

/**
 * Represents a user in the system with a username, email, and password.
 */
public class User {
    private String username;
    private String email;
    private String password;

    /**
     * Constructs a User object with the specified username, email, and password.
     *
     * @param name     The username of the user.
     * @param email    The email of the user.
     * @param password The password of the user.
     */
    public User(String name, String email, String password) {
        this.username = name;
        this.password = password;
        this.email = email;
    }

    /**
     * Gets the email of the user.
     *
     * @return The email of the user.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Gets the username of the user.
     *
     * @return The username of the user.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Gets the password of the user.
     *
     * @return The password of the user.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Checks if the provided password is correct.
     *
     * @param passwordPosted The password introduced for validation.
     * @return true if the provided password matches the user's password, false otherwise.
     */
    public boolean passwordIsCorrect(String passwordPosted){
        return passwordPosted.equals(getPassword());
    }
}
