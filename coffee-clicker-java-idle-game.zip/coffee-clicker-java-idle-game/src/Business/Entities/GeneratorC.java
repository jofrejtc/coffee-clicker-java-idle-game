package Business.Entities;
/**
 * Implementation of the Generator interface for Generator type C.
 */
public class GeneratorC implements Generator{
    private String type = "C";
    private int howMany;
    private float price;
    private float production;
    private int miliSeconds;
    private double priceIncrement;
    /**
     * Constructs a GeneratorC with default values.
     */
    public GeneratorC(){
        this.howMany = 0;
        this.price = 2000;
        this.production = 15.0F;
        this.priceIncrement = 1.12F;
        this.miliSeconds = 1000;
    }

    @Override
    public void setHowMany(int howMany) {
        this.howMany = howMany;
    }

    @Override
    public int getHowMany() {
        return howMany;
    }
    @Override
    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String getType() {
        return this.type;
    }

    @Override
    public float getPrice() {
        return this.price;
    }

    @Override
    public void setPrice(float price) {
        this.price = price;
    }

    @Override
    public float getProduction() {
        return this.production;
    }

    @Override
    public void setProduction(float production) {
        this.production = production;
    }

    @Override
    public double getPriceIncrement() {
        return this.priceIncrement;
    }

    @Override
    public void setPriceIncrement(double priceIncrement) {
        this.priceIncrement = priceIncrement;
    }


    @Override
    public void setNumberMiliseconds(int miliSeconds) {
        this.miliSeconds = miliSeconds;//Needs 66.6 miliseconds(0.066 seconds) to increment to 1 cofee
    }

    @Override
    public int getHowManyMacacosToIncrement() {
        return 15;
    }

    @Override
    public int getNumberMiliseconds() {
        return this.miliSeconds;
    }
}
