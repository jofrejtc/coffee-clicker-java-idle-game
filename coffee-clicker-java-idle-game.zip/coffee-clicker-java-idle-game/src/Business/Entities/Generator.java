package Business.Entities;

/**
 * Interface representing a generator with methods to get and set its properties.
 */
public interface Generator {
    /**
     * Sets the type of the generator.
     *
     * @param type The type of the generator.
     */
    void setType(String type);

    /**
     * Gets the type of the generator.
     *
     * @return The type of the generator.
     */
    String getType();

    /**
     * Sets the number of generators.
     *
     * @param howMany The number of generators.
     */
    void setHowMany(int howMany);

    /**
     * Gets the number of generators.
     *
     * @return The number of generators.
     */
    int getHowMany();

    /**
     * Gets the price of the generator.
     *
     * @return The price of the generator.
     */
    float getPrice();

    /**
     * Sets the price of the generator.
     *
     * @param price The price of the generator.
     */
    void setPrice(float price);

    /**
     * Gets the production rate of the generator.
     *
     * @return The production rate of the generator.
     */
    float getProduction();

    /**
     * Sets the production rate of the generator.
     *
     * @param production The production rate of the generator.
     */
    void setProduction(float production);

    /**
     * Gets the price increment rate of the generator.
     *
     * @return The price increment rate of the generator.
     */
    double getPriceIncrement();

    /**
     * Sets the price increment rate of the generator.
     *
     * @param priceIncrement The price increment rate of the generator.
     */
    void setPriceIncrement(double priceIncrement);

    /**
     * Gets the number of macacos to increment.
     *
     * @return The number of macacos to increment.
     */
    int getHowManyMacacosToIncrement();

    /**
     * Gets the number of milliseconds for the generator.
     *
     * @return The number of milliseconds for the generator.
     */
    int getNumberMiliseconds();

    /**
     * Sets the number of milliseconds for the generator.
     *
     * @param miliseconds The number of milliseconds for the generator.
     */
    void setNumberMiliseconds(int miliseconds);
}
