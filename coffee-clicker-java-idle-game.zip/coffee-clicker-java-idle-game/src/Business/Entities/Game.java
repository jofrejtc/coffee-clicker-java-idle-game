package Business.Entities;

import Exceptions.BusinessException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
/**
 * Represents a game with various attributes and methods to manage game state,
 * including generators and resources.
 */
public class Game {
    private int userId;
    private int id;
    private float resourceCounter;
    private boolean finishedGame;
    private ArrayList<Generator> allGenerators;
    private float totalProduction;

    /**
     * Constructs a Game object with the specified parameters.
     *
     * @param userId          The user ID associated with the game.
     * @param id              The game ID.
     * @param resourceCounter The initial resource counter value.
     * @param finishedGame    The initial finished game state.
     * @param totalProduction The initial total production value.
     * @throws BusinessException if there is an error initializing the generators.
     */
    public Game(int userId, int id, int resourceCounter, boolean finishedGame, float totalProduction) throws BusinessException {
        this.userId = userId;
        this.resourceCounter = resourceCounter;
        this.finishedGame = finishedGame;
        this.totalProduction = totalProduction;
        this.allGenerators = fullGenerators();
        this.id = id;
    }

    /**
     * Constructs a Game object with default values.
     *
     * @throws BusinessException if there is an error initializing the generators.
     */
    public Game() throws BusinessException {
        userId = 0;
        resourceCounter= 0;
        finishedGame = false;
        totalProduction = 0;
        allGenerators = fullGenerators();
        id = 0;
    }

    /**
     * Sets new generator counts based on the provided list.
     *
     * @param numberOfEachGenerator The list of generator counts.
     */
    public void setNewGenerator(ArrayList<Integer> numberOfEachGenerator) {
        for (int i = 0; i < numberOfEachGenerator.size(); i++) {
            allGenerators.get(i).setHowMany(numberOfEachGenerator.get(i));
        }
    }
    /**
     * Returns the count of each generator type.
     *
     * @return A list of generator counts.
     */
    public ArrayList<Integer> returnHowManyGenerators(){
        ArrayList<Integer> howManyGenerators = new ArrayList<>();
        for (int i = 0; i < allGenerators.size(); i++) {
            howManyGenerators.add(allGenerators.get(i).getHowMany());
        }
        return howManyGenerators;
    }

    /**
     * Initializes and returns a list of all generators.
     *
     * @return A list of all generators.
     * @throws BusinessException if there is an error creating a generator.
     */
    private ArrayList<Generator> fullGenerators() throws BusinessException {
        ArrayList<Generator> generators = new ArrayList<>();

        generators.add(createGenerator("A"));
        generators.add(createGenerator("B"));
        generators.add(createGenerator("C"));

        return generators;
    }

    /**
     * Creates and returns a generator of the specified type.
     *
     * @param type The type of generator to create.
     * @return The created generator.
     * @throws BusinessException if the generator type is invalid.
     */
    public Generator createGenerator(String type) throws BusinessException {
        return switch (type) {
            case "A" -> new GeneratorA();
            case "B" -> new GeneratorB();
            case "C" -> new GeneratorC();
            default -> throw new BusinessException("Invalid generator type: " + type);
        };
    }

    /**
     * Returns the cost increment for the specified generator type.
     *
     * @param row The index of the generator type.
     * @return The cost increment.
     * @throws BusinessException if the generator type is invalid.
     */
    public double returnIncrementCost(int row) throws BusinessException {
        double increment;
        switch (row) {
            case 0:
                GeneratorA generatorA = new GeneratorA();
                increment= generatorA.getPriceIncrement();
                return increment;
            case 1:
                GeneratorB generatorB = new GeneratorB();
                increment= generatorB.getPriceIncrement();
                return increment;
            case 2:
                GeneratorC generatorC = new GeneratorC();
                increment= generatorC.getPriceIncrement();
                return increment;
            default:
                throw new BusinessException("Invalid generator type: " + row);
        }
    }
    /**
     * Constructs a Game object with the specified user ID and game ID.
     *
     * @param userId The user ID associated with the game.
     * @param id     The game ID.
     */
    public Game(int userId, int id){
        this.userId = userId;
        this.id = id;
        resourceCounter = 0;
        finishedGame = false;
        totalProduction = 0;
        allGenerators = new ArrayList<>();
    }


    /**
     * Calculates the decrement value for the specified generator type.
     *
     * @param decrease    The initial decrement value.
     * @param selectedRow The index of the generator type.
     * @return The calculated decrement value.
     * @throws BusinessException if there is an error retrieving the increment cost.
     */
    public float howManyDecrees(float decrease, int selectedRow) throws BusinessException {

        double currentCount = allGenerators.get(selectedRow).getHowMany();
        double increment= Math.pow(returnIncrementCost(selectedRow),currentCount);

        double result = decrease * increment;

        BigDecimal roundedResult = BigDecimal.valueOf(result).setScale(2, RoundingMode.HALF_UP);
        return roundedResult.floatValue();
    }

    /**
     * Adds an owned generator of the specified type.
     *
     * @param generatorType The type of generator to add.
     */
    public void addOwnedGenerator(int generatorType) {

        int currentCount = allGenerators.get(generatorType).getHowMany();

        allGenerators.get(generatorType).setHowMany(currentCount);
    }

    /**
     * return the id
     * @return the id of a game
     */
    public int getId() {
        return id;
    }

    /**
     * sets an id for the game
     * @param id id of the game
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * returns the userId of the Game.
     * @return the user id of the game.
     */
    public int getUserId() {
        return userId;
    }

    /**
     * sets the userId of the game.
     * @param userId the user id of the game.
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * returns the resourceCounter of the game.
     * @return the resource counter of the game.
     */
    public float getResourceCounter() {
        return resourceCounter;
    }

    /**
     * returns the finished game boolean.
     * @return the boolean of the finished game.
     */
    public boolean getFinishedGame() {
        return finishedGame;
    }

    /**
     * sets a resource counter for the game
     * @param resourceCounter counter of macacos.
     */
    public void setResourceCounter(float resourceCounter) {
        this.resourceCounter = resourceCounter;
    }

    /**
     * sets the finished game boolean
     * @param finishedGame boolean that indicates if the game is finished
     */
    public void setFinishedGame(boolean finishedGame) {
        this.finishedGame = finishedGame;
    }

    /**
     * returns the total production of a game.
     * @return total production of game.
     */
    public float getTotalProduction() {
        return totalProduction;
    }

    /**
     * sets total production to game
     * @param totalProduction total production of a game.
     */
    public void setTotalProduction(float totalProduction) {
        this.totalProduction = totalProduction;
    }

    /**
     * return all the generators of game.
     * @return the generators og game.
     */
    public ArrayList<Generator> getAllGenerators() {
        return allGenerators;
    }

    /**
     * sets all the generators to game
     * @param allGenerators generators of the game.
     */
    public void setAllGenerators(ArrayList<Generator> allGenerators) {
        this.allGenerators = allGenerators;
    }
}