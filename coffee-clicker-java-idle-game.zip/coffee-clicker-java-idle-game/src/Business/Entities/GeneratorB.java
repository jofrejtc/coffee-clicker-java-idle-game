package Business.Entities;

/**
 * Implementation of the Generator interface for Generator type B.
 */
public class GeneratorB implements Generator{
    private String type = "B";
    private int howMany;
    private float price;
    private float production;
    private int miliSeconds;
    private double priceIncrement;
    /**
     * Constructs a GeneratorB with default values.
     */
    public GeneratorB(){
        this.howMany = 0;
        this.price = 150;
        this.production = 1.0F;
        this.priceIncrement = 1.15F;
        this.miliSeconds = 1000;
    }

    @Override
    public void setHowMany(int howMany) {
        this.howMany = howMany;
    }

    @Override
    public int getHowMany() {
        return howMany;
    }
    @Override
    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String getType() {
        return this.type;
    }

    public float getPrice() {
        return this.price;
    }

    @Override
    public void setPrice(float price) {
        this.price = price;
    }

    @Override
    public float getProduction() {
        return this.production;
    }

    @Override
    public void setProduction(float production) {
        this.production = production;
    }

    @Override
    public double getPriceIncrement() {
        return this.priceIncrement;
    }

    @Override
    public void setPriceIncrement(double priceIncrement) {
        this.priceIncrement = priceIncrement;
    }

    @Override
    public int getNumberMiliseconds() {
        return this.miliSeconds;
    }

    @Override
    public void setNumberMiliseconds(int miliseconds) {
        this.miliSeconds = miliseconds;
    }

    @Override
    public int getHowManyMacacosToIncrement() {
        return 1;
    }

}
