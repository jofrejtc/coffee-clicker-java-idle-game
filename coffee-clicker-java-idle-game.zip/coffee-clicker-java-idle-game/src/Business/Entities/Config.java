package Business.Entities;

/**
 * Configuration class that holds the database connection details.
 */
public class Config {
    private final String username;
    private final String password;
    private final String ip;
    private final int port;
    private final String database;

    /**
     * Constructs a Config object with the specified database connection details.
     *
     * @param username The username for the database connection.
     * @param password The password for the database connection.
     * @param ip       The IP address of the database server.
     * @param port     The port number of the database server.
     * @param database The name of the database.
     */
    public Config(String username, String password, String ip, int port, String database) {
        this.username = username;
        this.password = password;
        this.ip = ip;
        this.port = port;
        this.database = database;
    }

    /**
     * Gets the username for the database connection.
     *
     * @return The username.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Gets the password for the database connection.
     *
     * @return The password.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Gets the IP address of the database server.
     *
     * @return The IP address.
     */
    public String getIp() {
        return ip;
    }

    /**
     * Gets the port number of the database server.
     *
     * @return The port number.
     */
    public int getPort() {
        return port;
    }

    /**
     * Gets the name of the database.
     *
     * @return The database name.
     */
    public String getDatabase() {
        return database;
    }
}
