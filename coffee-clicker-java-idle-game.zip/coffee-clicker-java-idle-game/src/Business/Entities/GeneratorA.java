package Business.Entities;
/**
 * Implementation of the Generator interface for Generator type A.
 */
public class GeneratorA implements Generator{
    private String type = "A";
    private int howMany;
    private float price;
    private float production;
    private double priceIncrement;
    private int miliSeconds;
    /**
     * Constructs a GeneratorA with default values.
     */
    public GeneratorA(){
        this.howMany = 0;
        this.price = 10;
        this.production = 0.2F;
        this.priceIncrement = 1.07F;
        this.miliSeconds = 5000;
    }

    /**
     * sets number of generators
     * @param howMany The number of generators.
     */
    @Override
    public void setHowMany(int howMany) {
        this.howMany = howMany;
    }

    /**
     * return the number of generators
     * @return number of generators.
     */
    @Override
    public int getHowMany() {
        return howMany;
    }

    /**
     * returns of the price.
     * @return price of the generator.
     */
    @Override
    public float getPrice() {
        return price;
    }

    /**
     * return the production of the generator
     * @return production of the generator
     */
    @Override
    public float getProduction() {
        return production;
    }

    /**
     * gets the price increment for the generator
     * @return price increment for the generator.
     */
    @Override
    public double getPriceIncrement() {
        return priceIncrement;
    }

    /**
     * returns the miliseconds of the generator.
     * @return miliseconds of the generator
     */
    public int getMiliSeconds() {
        return miliSeconds;
    }

    /**
     * puts a type for the generator.
     * @param type The type of the generator.
     */
    @Override
    public void setType(String type) {
        this.type = type;
    }

    /**
     * returns the type for the generator
     * @return the type of generator
     */
    @Override
    public String getType() {
        return this.type;
    }

    /**
     * gets the number of generators to increment.
     * @return number of generators to increment.
     */
    @Override
    public int getHowManyMacacosToIncrement() {
        return 1;
    }

    /**
     * gets the number of miliseconds
     * @return the number of miliseconds of the generator.
     */
    @Override
    public int getNumberMiliseconds() {
        return this.miliSeconds;
    }

    /**
     * sets a number of generators for the generator.
     * @param miliSeconds The number of milliseconds for the generator.
     */
    @Override
    public void setNumberMiliseconds(int miliSeconds) {
        this.miliSeconds = miliSeconds;
    }

    /**
     * sets a price for the generator.
     * @param price The price of the generator.
     */
    public void setPrice(float price) {
        this.price = price;
    }

    /**
     * sets a production for a generator.
     * @param production The production rate of the generator.
     */
    public void setProduction(float production) {
        this.production = production;
    }

    /**
     * sets a price increment to a generator.
     * @param priceIncrement The price increment rate of the generator.
     */
    public void setPriceIncrement(double priceIncrement) {
        this.priceIncrement = priceIncrement;
    }
}
