package Business.Managers;

import Business.Entities.Game;
import Business.Entities.Generator;
import Exceptions.*;
import Persistence.GameJSONDAO;
import Persistence.GameSQLDAO;
import Persistence.json.GameJSON;
import Persistence.sql.GameSQL;
import Presentation.Controllers.GameObserver;

import java.util.ArrayList;
import java.util.List;
/**
 * Manages the game operations including creating new games, loading games,
 * upgrading generators, and managing macacos.
 */
public class GameManager {
    private final GameSQLDAO gameDAO;
    private Game currentGame;
    private final GameJSONDAO gameJSON;
    private int costBaseA = 10,costBaseB = 150,costBaseC = 2000;
    private static final float DECREASE_VALUE_A = 10.0F;
    private static final float DECREASE_VALUE_B = 150.0F;
    private static final float DECREASE_VALUE_C = 2000.0F;
    private final List<GameObserver> observers;
    private final List<Thread> threadList = new ArrayList<>();

    /**
     * Adds an observer to the game.
     *
     * @param observer The observer to add.
     */
    public void addObserver(GameObserver observer) {
        observers.add(observer);
    }
    /**
     * Notifies all observers with the current macaco number.
     *
     * @param macacoNumber The current macaco number.
     */
    private void notifyObservers(float macacoNumber) {
        for (GameObserver observer : observers) {
            observer.updateMacacoNumber(macacoNumber);
        }
    }

    /**
     * Constructs a GameManager with the specified GameSQL.
     *
     * @param gameSQL The GameSQL to use for SQL operations.
     */
    public GameManager(GameSQL gameSQL){
        observers = new ArrayList<>();
        gameJSON = new GameJSON();
        gameDAO = gameSQL;
        currentGame = new Game(0, 0);
    }

    /**
     * Returns information about the current game including the number of macacos.
     *
     * @param id The game ID.
     * @return The Game object with the current information.
     * @throws BusinessException if there is an error loading the game.
     */
    public Game returnInformationOfNumberOfMacacos(int id) throws BusinessException {
        String fileNameActualGame = "game_" + id + ".json";

        if(gameJSON.doesFileExist(fileNameActualGame)){
            Game gameActual;
            try {
                gameActual = gameJSON.loadGame(id);
            } catch (PersistenceException e) {
                throw  new BusinessException(e.getMessage());
            }

            currentGame = gameActual;

            return gameActual;
        }
        return null;
    }

    /**
     * Creates a new game for the specified user ID.
     *
     * @param userId The user ID of the player.
     * @throws BusinessException if there is an error during game creation or saving.
     */
    public void createNewGame(int userId) throws BusinessException {
        List<Game> games = orderedAllGames();

        int resourceCounter = 0;
        boolean finishedGame = false;
        float totalProduction = 0.0f;
        Game game = new Game(userId, games.size(), resourceCounter, finishedGame, totalProduction);
        String fileName;

        try {
            fileName = gameJSON.saveGame(game);
        } catch (PersistenceException e) {
            throw new BusinessException(e.getMessage());
        }

        currentGame = new Game(userId, games.size());

        try {
            if (gameDAO.addGame(userId, currentGame.getId())) {
                currentGame.setId(gameDAO.getLastGameId());
                if (fileName != null) {
                    gameDAO.updateGameJsonPath(currentGame.getId(), fileName);
                }
            }
            gameJSON.setAllGamesToPersistence(games);
        } catch (PersistenceException e){
            throw new BusinessException(e.getMessage());
        }
    }

    /**
     * Orders all games from SQL and JSON persistence.
     *
     * @return A list of ordered games.
     * @throws BusinessException if there is an error during retrieval.
     */
    private List<Game> orderedAllGames() throws BusinessException {
        List<Game> gamesSQL ;
        try {
            gamesSQL = gameDAO.getAllGames();
        } catch (PersistenceException e) {
            throw new BusinessException(e.getMessage());
        }
        List<Game> games = gameJSON.chargeAllGamesFromPersistence();
        int minSize = Math.min(gamesSQL.size(), games.size());
        for(int compt = 0; compt < minSize; compt++){
            games.get(compt).setId(gamesSQL.get(compt).getId());
        }
        return games;
    }
    /**
     * Gets the initial number of macacos for the specified game ID.
     *
     * @param gameId The game ID.
     * @return The initial number of macacos.
     * @throws BusinessException if there is an error during retrieval.
     */
    public float getInitialMacacoNumber(int gameId) throws BusinessException {
        Game updatedGame = returnInformationOfNumberOfMacacos(gameId);
        try {
            return  updatedGame.getResourceCounter();
        } catch (MacacoNumberException e){
            return 0;
        }
    }

    /**
     * Gets the information of the last game.
     *
     * @return A list of strings with the last game's information.
     */
    public ArrayList<String> getLastGameInfo() {
        ArrayList<String> gameInfo = new ArrayList<>();
        gameInfo.add(String.valueOf(currentGame.getId()));
        gameInfo.add(String.valueOf(currentGame.getResourceCounter()));
        gameInfo.add(String.valueOf(currentGame.getFinishedGame()));
        gameInfo.add(String.valueOf(currentGame.getAllGenerators()));

        gameInfo.add(String.valueOf(currentGame.getTotalProduction()));
        return gameInfo;
    }

    /**
     * Increases the number of macacos by clicking.
     *
     * @return The updated Game object.
     * @throws BusinessException if there is an error during the operation.
     */
    public Game increaseMacacosWithTheClick() throws BusinessException {
        currentGame = updateIncrementMacacos(currentGame,1);
        try {
            gameJSON.saveGame(currentGame);
        } catch (PersistenceException e) {
            throw new BusinessException(e.getMessage());
        }
        return currentGame;
    }

    /**
     * Synchronized method to increment macacos from both clicker and thread.
     *
     * @param gameActual The current game object.
     * @param howManyMacacos The number of macacos to increment.
     * @return The updated game object.
     */
    synchronized private Game updateIncrementMacacos(Game gameActual,int howManyMacacos) {
        gameActual.setResourceCounter(gameActual.getResourceCounter() + howManyMacacos);
        return gameActual;
    }

    /**
     * Implements the logic to decrement the number of macacos each time a generator is purchased.
     * Uses a mathematical formula to determine the decrement amount. Note that the first time it
     * does not enter the if statements because the base cost is assigned initially.
     *
     * @param selectedRow The index of the selected generator.
     * @return The updated Game object after the macacos have been decremented and the generator has been added.
     * @throws NoMoreMacacosException if there are not enough macacos to perform the decrement.
     * @throws BusinessException if there is an error processing the game data.
     */
    public Game decreaseMacacos(int selectedRow) throws NoMoreMacacosException, BusinessException {

        float decrease = 0.0F;
        ArrayList<Integer> howManyGenerators=currentGame.returnHowManyGenerators();

        if(selectedRow==0){
            decrease = DECREASE_VALUE_A;
            if(howManyGenerators.get(selectedRow)!=0) {
                decrease = currentGame.howManyDecrees(decrease, selectedRow);
                costBaseA = Math.round(decrease);
            }
        }
        else if(selectedRow==1){
            decrease= DECREASE_VALUE_B;
            if(howManyGenerators.get(selectedRow)!=0) {
                decrease = currentGame.howManyDecrees(decrease, selectedRow);
                costBaseB = Math.round(decrease);
            }
        }
        else if(selectedRow==2){
            decrease= DECREASE_VALUE_C;
            if(howManyGenerators.get(selectedRow)!=0) {
                decrease = currentGame.howManyDecrees(decrease, selectedRow);
                costBaseC = Math.round(decrease);
            }
        }
        float resultatRestar = currentGame.getResourceCounter() - Math.round(decrease);
        if(resultatRestar >= 0){
            currentGame.addOwnedGenerator(selectedRow);
            deleteMacacos(decrease);
            makeThreadStaff(currentGame.getAllGenerators(),selectedRow);

        }
        else{
            throw new NoMoreMacacosException("NO TENS ELS MACACOS NECESSARIS :(");
        }

        return currentGame;
    }

    /**
     * Reinitializes the threads of a previously created game.
     *
     * @param gameId The game ID.
     * @throws BusinessException if there is an error during the operation.
     */
    public void enterGame(int gameId) throws BusinessException {
        try {

            List<Game> gamesFromJson = gameJSON.chargeAllGamesFromPersistence();
            currentGame = gamesFromJson.get(gameId);

            currentGame = gameJSON.loadGame(gameId);
            for (int i = 0; i < currentGame.getAllGenerators().size(); i++) {
                for (int j = 0; j < currentGame.getAllGenerators().get(i).getHowMany(); j++) {
                    makeThreadStaff(currentGame.getAllGenerators(),i);
                }
            }

        }
        catch (PersistenceException e){
            throw new BusinessException("There are less games than the game you want to play, that is the " + gameId);
        }
    }

    /**
     * Adds a generator to the game based on the provided row data.
     *
     * @param rowData The data of the row.
     * @throws BusinessException if there is an error during the operation.
     */
    public void addGeneratorToGame(Object[] rowData) throws BusinessException {
        ArrayList<Integer>  numberOfEachGenerator = currentGame.returnHowManyGenerators();

        List<String> rowDataList = new ArrayList<>();

        for (Object obj : rowData) {
            if (obj != null) {
                rowDataList.add(obj.toString());
            } else {
                rowDataList.add(null);
            }
        }

        switch (rowDataList.get(0)){
            case "A":
                numberOfEachGenerator.set(0, numberOfEachGenerator.get(0)+1);
                break;
            case "B":
                numberOfEachGenerator.set(1, numberOfEachGenerator.get(1)+1);
                break;
            case "C":
                numberOfEachGenerator.set(2, numberOfEachGenerator.get(2)+1);
                break;
            default:
        }

        currentGame.setNewGenerator(numberOfEachGenerator);
        try {
            gameJSON.saveGame(currentGame);
        } catch (PersistenceException e) {
            throw new BusinessException(e.getMessage());
        }
    }

    /**
     * Creates a thread for each generator purchased. The thread will call the
     * updateIncrementMacacos function every x seconds to increment the number of macacos.
     * Manages exceptions related to thread interruptions.
     * Stores all threads in a global list to stop them in the future if necessary.
     *
     * @param generators The list of generators in the game.
     * @param selectedRow The index of the selected generator.
     */
    private void makeThreadStaff(ArrayList<Generator> generators, int selectedRow) {

        Thread generatorThread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    ArrayList<Generator> generators1 = currentGame.getAllGenerators();
                    updateIncrementMacacos(currentGame,generators.get(selectedRow).getHowManyMacacosToIncrement());
                    int miliSeconds = generators1.get(selectedRow).getNumberMiliseconds();
                    Thread.sleep(miliSeconds);
                    notifyObservers(currentGame.getResourceCounter());

                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });

        threadList.add(generatorThread);
        generatorThread.start();
    }

    /**
     * Stops all running threads and clears the observer list.
     */
    public void stopAllThreads() {
        for (Thread thread : threadList) {
            thread.interrupt();
        }
        threadList.clear();

        observers.clear();
    }

    /**
     * Retrieves information for all games based on the specified attribute.
     *
     * @param atribute The attribute to retrieve information for.
     * @return A list of strings with the requested information.
     * @throws BusinessException if there is an error during the operation.
     */
    public ArrayList<String> getAllGamesInfo(String atribute) throws BusinessException {
        List<Game> allGames = orderedAllGames();
        ArrayList<String> allInfo = new ArrayList<>();

        switch (atribute){
            case "userId":
                for (Game allGame1 : allGames) {
                    allInfo.add(String.valueOf(allGame1.getUserId()));
                }
                break;
            case "id":
                for (Game element : allGames) {
                    allInfo.add(String.valueOf(element.getId()));
                }
                break;
            case "resourceCounter":
                for (Game item : allGames) {
                    allInfo.add(String.valueOf(item.getResourceCounter()));
                }
                break;
            case "finishedGame":
                for (Game value : allGames) {
                    allInfo.add(String.valueOf(value.getFinishedGame()));
                }
                break;
           case "ownedGenerators":
               for (Game game : allGames) {
                   allInfo.add(String.valueOf(totalGeneratorsOfGameWithAGame(game)));
               }
                break;
            case "allGenerators":
                for (Game allGame : allGames) {
                    allInfo.add(String.valueOf(allGame.getAllGenerators()));
                }
                break;
            case "totalProduction":
                for (Game allGame : allGames) {
                    allInfo.add(String.valueOf(allGame.getTotalProduction()));
                }
                break;
        }
        return allInfo;
    }

    /**
     * Calculates the total number of generators in a game.
     *
     * @param game The game object.
     * @return The total number of generators.
     */
    public int totalGeneratorsOfGameWithAGame(Game game){
        ArrayList<Integer> totalGenerators = game.returnHowManyGenerators();
        int realTotal = 0;
        for(int compt = 0; compt < totalGenerators.size(); compt++){
            realTotal += totalGenerators.get(compt);
        }
        return realTotal;
    }

    /**
     * Gets the updated base costs for the generators.
     *
     * @return A list of integers representing the base costs.
     */
    public ArrayList<Integer> getInfoCostBase() {
        ArrayList<Integer> costsBasesUpdated= new ArrayList<>();
        costsBasesUpdated.add(costBaseA);
        costsBasesUpdated.add(costBaseB);
        costsBasesUpdated.add(costBaseC);
        return costsBasesUpdated;
    }

    /**
     * Gets the current game ID.
     *
     * @return The current game ID.
     */
    public int getCurrentGameId() {
        return currentGame.getId();
    }

    /**
     * Retrieves information for the macaco table based on the current generators.
     *
     * @return A list of strings with the generator information.
     * @throws BusinessException if there is an error during the operation.
     */
    public ArrayList<String> currentGeneratorsInfoForMacacoTable() throws BusinessException {
        GeneratorManager generatorManager = new GeneratorManager();
        ArrayList<String> infoGenerators = new ArrayList<>();
        ArrayList<Generator> generators = currentGame.getAllGenerators();
        ArrayList<Integer> currentGeneratorsInteger = currentGame.returnHowManyGenerators();
        float totalProductionA ;
        float totalProductionB ;
        float totalProductionC ;
        try{

            totalProductionA = generators.get(0).getProduction() * currentGeneratorsInteger.get(0);

            totalProductionB = generators.get(1).getProduction() * currentGeneratorsInteger.get(1);

            totalProductionC = generators.get(2).getProduction() * currentGeneratorsInteger.get(2);

            if(currentGeneratorsInteger.get(0) > 0){
                infoGenerators.add(generators.get(0).getType());
                infoGenerators.add(String.valueOf(currentGeneratorsInteger.get(0)));
                infoGenerators.add(generators.get(0).getProduction() + " c/s");
                infoGenerators.add(totalProductionA + " c/s");
                infoGenerators.add(generatorManager.calculateGlobalProduction("A", totalProductionA, totalProductionB, totalProductionC));
            }
            if(currentGeneratorsInteger.get(1) > 0){
                infoGenerators.add(generators.get(1).getType());
                infoGenerators.add(String.valueOf(currentGeneratorsInteger.get(1)));
                infoGenerators.add(generators.get(1).getProduction() + " c/s");
                infoGenerators.add(totalProductionB + " c/s");
                infoGenerators.add(generatorManager.calculateGlobalProduction("B", totalProductionA, totalProductionB, totalProductionC));
            }
            if(currentGeneratorsInteger.get(2) > 0){
                infoGenerators.add(generators.get(2).getType());
                infoGenerators.add(String.valueOf(currentGeneratorsInteger.get(2)));
                infoGenerators.add(generators.get(2).getProduction() + " c/s");
                infoGenerators.add(totalProductionC + " c/s");
                infoGenerators.add(generatorManager.calculateGlobalProduction("C", totalProductionA, totalProductionB, totalProductionC));
            }

        } catch (IndexOutOfBoundsException e){
            throw new BusinessException("There was a problem recolecting the information of the generators to the table.");
        }

        return infoGenerators;
    }

    /**
     * Marks the current game as finished.
     *
     * @throws BusinessException if there is an error during the operation.
     */
    public void finishActualGame() throws BusinessException {
        currentGame.setFinishedGame(true);
        try {
            gameJSON.saveGame(currentGame);
        } catch (PersistenceException e) {
            throw new BusinessException(e.getMessage());
        }
    }

    /**
     * Saves the current game.
     *
     * @throws BusinessException if there is an error during the operation.
     */
    public void saveCurrentGame() throws BusinessException {
        calculateTotalProductionOfGame(currentGame);
        try {
            gameJSON.saveGame(currentGame);
        } catch (PersistenceException e) {
            throw new BusinessException(e.getMessage());
        }
    }

    /**
     * Calculates the total production of the game.
     *
     * @param game The game object.
     */
    private void calculateTotalProductionOfGame(Game game) {
        float totalProduction = 0;

        ArrayList<Generator> generatorsInGame = game.getAllGenerators();

        for(int compt = 0; compt < 3; compt++){
            totalProduction += generatorsInGame.get(compt).getProduction() * generatorsInGame.get(compt).getHowMany();
        }
        game.setTotalProduction(totalProduction);
    }

    /**
     * Applies an upgrade multiplier to all generators of a specified type within the game.
     *
     * @param generatorType The type of the generator to upgrade.
     * @param multiplier    The multiplier to apply to the generator's production.
     * @return {@code true} if at least one generator was successfully upgraded, {@code false} otherwise.
     */
    public boolean applyUpgrade (String generatorType, double multiplier) {
        ArrayList<Generator> generators = currentGame.getAllGenerators();
        GeneratorManager generatorManager = new GeneratorManager();

        if (generatorManager.applyUpgradeToGenerator(generators, generatorType, multiplier)) {
            currentGame.setAllGenerators(generators);
            try {
                gameJSON.saveGame(currentGame);
            } catch (PersistenceException e) {
                return false;
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * Deletes the games of a specified user.
     *
     * @param userId The user ID.
     * @return {@code true} if the games were successfully deleted, {@code false} otherwise.
     * @throws LogOutException if no user is currently logged in.
     * @throws BusinessException if there is an error during the operation.
     */
    public boolean deleteUserGames(int userId) throws LogOutException, BusinessException {
        boolean isDeleted ;

        try {
            isDeleted = gameDAO.deleteGamesByUser(userId);
        } catch (PersistenceException e) {
            throw new BusinessException(e.getMessage());
        }
        if (!isDeleted) {
            throw new LogOutException("No user is currently logged in.");
        }
        return true;
    }

    /**
     Attempts to decrement the number of macacos based on the given decrement amount.
     It updates the resource counter of the current game if there are sufficient macacos available.
     Throws an exception if there are not enough macacos.*
     @param decreaseAmount The amount to decrease the macacos by.
     @throws BusinessException     if there is an error processing the game data.
     @throws NoMoreMacacosException if there are not enough macacos to perform the decrement.
     */
    public void deleteMacacos(float decreaseAmount) throws NoMoreMacacosException, BusinessException {
        float currentMacacos = currentGame.getResourceCounter();

        if (currentMacacos >= decreaseAmount) {
            currentGame.setResourceCounter(currentMacacos - decreaseAmount);
            try {
                gameJSON.saveGame(currentGame);
            } catch (PersistenceException e) {
                throw new BusinessException(e.getMessage());
            }
        } else {
            throw new NoMoreMacacosException("NO TENS ELS MACACOS NECESSARIS :(");
        }
    }
}
