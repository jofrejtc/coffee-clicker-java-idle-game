package Business.Managers;
/**
 * Manages upgrades for generators in the system, determining generator types, production multipliers,
 * and prices based on upgrade table rows and columns.
 */
public class UpgradeManager {
    // Constants pels  generadores
    private static final String GENERATOR_A = "A";
    private static final String GENERATOR_B = "B";
    private static final String GENERATOR_C = "C";
    private static final double MULTIPLIER_2 = 2.0;
    private static final double MULTIPLIER_3 = 3.0;
    private static final double MULTIPLIER_4 = 4.0;
    private static final double MULTIPLIER_5 = 5.0;

    /**
     * Gets the generator type based on the row and column.
     *Cases defined by row and column that determine the generator type
     * @param row The row in the upgrade table.
     * @param col The column in the upgrade table.
     * @return The generator type as a string.
     */
    public String getGeneratorType(int row, int col) {
        String generatorType = "";
        if ((row >= 0 && row <= 3) && col == 2) {
            generatorType =GENERATOR_A;
        } else if ((row >= 0 && row <= 3) && col == 3) {
            generatorType = GENERATOR_B;
        } else if ((row >= 0 && row <= 3) && col == 4) {
            generatorType = GENERATOR_C;
        }
        return generatorType;
    }

    /**
     * Gets the production multiplier based on the row.
     *
     * @param row The row in the upgrade table.
     * @return The production multiplier as a double.
     */
    public double getProductionMultiplier(int row) {
        return switch (row) {
            case 0 -> MULTIPLIER_2;
            case 1 -> MULTIPLIER_3;
            case 2 -> MULTIPLIER_4;
            case 3 -> MULTIPLIER_5;
            default -> 0;
        };
    }

    /**
     * Gets the price of the upgrade based on the row and column.
     * Generator A, B, C prices.
     *
     * @param row The row in the upgrade table.
     * @param col The column in the upgrade table.
     * @return The price as a float.
     */
    public float getPrice(int row, int col) {
        float price = 0;
        if (col == 2) {
            price = switch (row) {
                case 0 -> 30;
                case 1 -> 60;
                case 2 -> 100;
                case 3 -> 200;
                default -> price;
            };
        } else if (col == 3) {
            price = switch (row) {
                case 0 -> 200;
                case 1 -> 400;
                case 2 -> 800;
                case 3 -> 1000;
                default -> price;
            };
        } else if (col == 4) {
            price = switch (row) {
                case 0 -> 1000;
                case 1 -> 2000;
                case 2 -> 5000;
                case 3 -> 10000;
                default -> price;
            };
        }
        return price;
    }
}