package Business.Managers;
import Business.Entities.User;
import Exceptions.*;
import Persistence.UserDAO;

import java.util.List;
import java.util.regex.Pattern;
/**
 * Manages user-related operations such as login, signup, and account deletion.
 */
public class UserManager {
    private final UserDAO userDAO;
    private User currentUser;

    /**
     * Dependency injection through the constructor
     *
     * @param userDAO The UserDAO implementation for database operations.
     */
    public UserManager(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    /**
     * Logs in the user to the system.
     *
     * @param credential The username/email of the user who wants to log in.
     * @param password The password of the account to log in.
     * @return boolean indicating if the login was successful.
     * @throws LogInException if there is an error during login.
     */
    public boolean logIn(String credential, String password) throws LogInException {

        User user;
        try {
            user = userDAO.getUserByUsernameOrEmail(credential);
        } catch (PersistenceException e) {
            throw new LogInException(e.getMessage());
        }
        if (user != null && user.passwordIsCorrect(password)) {
            currentUser = user;
            return true;
        }
        return false;
    }

    /**
     * Signs up the user, checking if all the credentials introduced are correct.
     *
     * @param userName The username of the account.
     * @param password The password of the account.
     * @param confirmPassword The confirmation password of the account.
     * @param email The email of the user.
     * @return boolean indicating if the signup was successful.
     * @throws BusinessException when some credential isn't valid or exists or when it is not possible to add the user to the database.
     * @throws SignUpException when the user credentials are invalid or already exist.
     */
    public boolean signUp(String userName, String password, String confirmPassword, String email) throws BusinessException, SignUpException {
        if(userName.isEmpty() || password.isEmpty() || email.isEmpty()){
            return false;
        }
        User newUser = new User(userName, email, password);

        User comproveIfUsernameUnique ;
        try {
            comproveIfUsernameUnique = userDAO.getUserByUsername(userName);
        } catch (PersistenceException e) {
            throw new BusinessException(e.getMessage());
        }
        if(comproveIfUsernameUnique!=null){
            throw new SignUpException("El nombre de usuario tiene que ser unico. Por favor, inténtelo de nuevo.");

        }
        User comproveIfEmailUnique;
        try {
            comproveIfEmailUnique = userDAO.getUserByEmail(email);
        } catch (PersistenceException e){
            throw new BusinessException(e.getMessage());
        }
        if(comproveIfEmailUnique!=null){
            throw new SignUpException("El email tiene que ser unico. Por favor, inténtelo de nuevo.");

        }
        if(!confirmPassword.equals(password)){
            throw new SignUpException("Las contraseñas no coinciden. Por favor, inténtelo de nuevo.");

        }
        String regexMailCorrect = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        if(!Pattern.compile(regexMailCorrect).matcher(email).matches()){
            throw new SignUpException("El formato del mail no es correcto. Por favor, inténtelo de nuevo.");
        }

        String regexPasswordContains = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,}$";
        if(!Pattern.compile(regexPasswordContains).matcher(password).matches()){
            throw new SignUpException("Las contraseña le falta un numero,o una mayuscula o una minuscula,o no contiene minimo 8 caracteres. Por favor, inténtelo de nuevo.");

        }

        boolean isAdded;
        try {
            isAdded = userDAO.addUser(newUser);
        } catch (PersistenceException e) {
            throw new BusinessException(e.getMessage());
        }
        if (isAdded) {
            currentUser = newUser;
            return true;
        } else {
            throw new SignUpException("The new user couldn't be saved");
        }
    }

    /**
     * Deletes the current user account from the system.
     *
     * @return true if the user is deleted.
     * @throws LogOutException if no user is currently logged in.
     * @throws BusinessException if there is an error during the operation.
     */
    public boolean deleteAccount() throws LogOutException, BusinessException {
        if (currentUser == null) {
            return false;
        }
        boolean isDeleted ;
        try {
            isDeleted = userDAO.deleteUser(currentUser);
        } catch (PersistenceException e) {
            throw new BusinessException(e.getMessage());
        }
        if (isDeleted) {
            if(!logOut()){
                throw new LogOutException("No user is currently logged in.");
            }
        }
        return isDeleted;
    }

    /**
     * Gets the ID of the current user.
     *
     * @return The ID of the current user.
     * @throws BusinessException if there is an error during the operation.
     */
    public int getCurrentUserId() throws BusinessException {
        try{
            return userDAO.getUserIdByEmail(currentUser.getEmail());
        } catch (PersistenceException e) {
            throw new BusinessException(e.getMessage());
        }
    }

    /**
     * Logs out the current user.
     *
     * @return true if the user was successfully logged out.
     */
    public boolean logOut() {
        if (currentUser != null) {
            currentUser = null;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Starts a new user session with the most recently added user.
     *
     * @throws BusinessException if there is an error during the operation.
     */
    public void startNewUser() throws BusinessException {
        List<User> users ;
        try {
            users = userDAO.getAllUsers();
        } catch (PersistenceException e) {
            throw new BusinessException(e.getMessage());
        }
        currentUser = users.get(users.size() - 1);
    }
}