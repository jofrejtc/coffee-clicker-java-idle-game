package Business.Managers;

import Business.Entities.Generator;

import java.util.ArrayList;
/**
 * Manages operations related to generators, including calculating global production
 * percentages and applying upgrades to generators.
 */

public class GeneratorManager {

    /**
     * Calculates the global production percentage for a specific generator type.
     *
     * @param generatorType The type of generator ("A", "B", or "C").
     * @param totalProductionA The total production of generator type A.
     * @param totalProductionB The total production of generator type B.
     * @param totalProductionC The total production of generator type C.
     * @return The global production percentage as a formatted string, or an error message if the generator type is not valid.
     */
    public String calculateGlobalProduction(String generatorType, float totalProductionA, float totalProductionB, float totalProductionC) {
        float globalProductionPercentage;
        float totalProduction = totalProductionA + totalProductionB + totalProductionC;
        switch (generatorType) {
            case "A":
                globalProductionPercentage = totalProductionA / totalProduction * 100;
                break;
            case "B":
                globalProductionPercentage = totalProductionB / totalProduction * 100;
                break;
            case "C":
                globalProductionPercentage = totalProductionC / totalProduction * 100;
                break;
            default:
                return "Tipo de generador no válido";
        }
        return String.format("%.2f%%", globalProductionPercentage);
    }

    /**
     * Applies an upgrade to all generators of a specific type in the list of generators.
     *
     * @param generators The list of generators to upgrade.
     * @param generatorType The type of generator to upgrade ("A", "B", or "C").
     * @param multiplier The multiplier to apply to the generator's production.
     * @return true if the upgrade was applied to at least one generator, false otherwise.
     */
    public boolean applyUpgradeToGenerator(ArrayList<Generator> generators, String generatorType, double multiplier){
        for (Generator gen : generators) {
            if (gen.getType().equals(generatorType)) {
                float newProduction = gen.getProduction() * (float) multiplier;
                int newMiliseconds =  (gen.getNumberMiliseconds() / (int) multiplier);
                gen.setProduction(newProduction);
                gen.setNumberMiliseconds(newMiliseconds);
                return true;
            }
        }
        return false;
    }
}
